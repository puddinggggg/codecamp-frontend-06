export default function Two() {
  return <div>two 영역 입니다</div>;
}
