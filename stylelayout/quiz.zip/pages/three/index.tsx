export default function Three() {
  return <div>three 영역 입니다</div>;
}
