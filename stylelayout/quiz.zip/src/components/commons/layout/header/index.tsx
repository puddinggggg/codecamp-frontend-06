import styled from "@emotion/styled";
export default function LayoutHeader() {
  const Wrapper = styled.div`
    background-color: orange;
    height: 50px;
  `;
  return <Wrapper>Header 헤더영역</Wrapper>;
}
