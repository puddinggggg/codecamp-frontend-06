import styled from '@emotion/styled'
// styled emotion 사용시 선언 첫 글자는 반드시 대문자
export const Wrap = styled.div`
width : 500px;
`;
export const MyTitle = styled.h2`
  text-align : center;
  `;
  export const List = styled.div`
  `;
  export const MyInfo = styled.input`
  width : 200px;`;