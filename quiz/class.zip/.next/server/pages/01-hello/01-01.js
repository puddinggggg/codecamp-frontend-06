"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/01-hello/01-01";
exports.ids = ["pages/01-hello/01-01"];
exports.modules = {

/***/ "./pages/01-hello/01-01/index.js":
/*!***************************************!*\
  !*** ./pages/01-hello/01-01/index.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Hello01)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n\nfunction Hello01() {\n    function Hello() {\n        document.getElementById(\"hi\").innerText = \"반갑습니다\";\n    }\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n            id: \"hi\",\n            onClick: Hello,\n            children: \"안녕하세요\"\n        }, void 0, false, {\n            fileName: \"C:\\\\Users\\\\cloubot\\\\Desktop\\\\quiz\\\\class\\\\pages\\\\01-hello\\\\01-01\\\\index.js\",\n            lineNumber: 10,\n            columnNumber: 1\n        }, this)\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\cloubot\\\\Desktop\\\\quiz\\\\class\\\\pages\\\\01-hello\\\\01-01\\\\index.js\",\n        lineNumber: 8,\n        columnNumber: 5\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8wMS1oZWxsby8wMS0wMS9pbmRleC5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQWUsUUFBUSxDQUFDQSxPQUFPLEdBQUUsQ0FBQzthQUVyQkMsS0FBSyxHQUFHLENBQUM7UUFFZEMsUUFBUSxDQUFDQyxjQUFjLENBQUMsQ0FBSSxLQUFFQyxTQUFTLEdBQUUsQ0FBTztJQUMxQyxDQUFUO0lBQ0wsTUFBTSw2RUFDREMsQ0FBRzs4RkFFUEMsQ0FBTTtZQUFDQyxFQUFFLEVBQUMsQ0FBSTtZQUFDQyxPQUFPLEVBQUVQLEtBQUs7c0JBQUUsQ0FBSzs7Ozs7Ozs7Ozs7QUFJckMsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2NsYXNzLy4vcGFnZXMvMDEtaGVsbG8vMDEtMDEvaW5kZXguanM/MmUwZCJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBIZWxsbzAxKCl7XHJcblxyXG4gICAgZnVuY3Rpb24gSGVsbG8oKSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJoaVwiKS5pbm5lclRleHQgPVwi67CY6rCR7Iq164uI64ukXCI7XHJcbiAgICB9XHJcbnJldHVybihcclxuICAgIDxkaXY+XHJcblxyXG48YnV0dG9uIGlkPVwiaGlcIiBvbkNsaWNrPXtIZWxsb30+7JWI64WV7ZWY7IS47JqUPC9idXR0b24+XHJcbjwvZGl2PlxyXG4pXHJcblxyXG59Il0sIm5hbWVzIjpbIkhlbGxvMDEiLCJIZWxsbyIsImRvY3VtZW50IiwiZ2V0RWxlbWVudEJ5SWQiLCJpbm5lclRleHQiLCJkaXYiLCJidXR0b24iLCJpZCIsIm9uQ2xpY2siXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/01-hello/01-01/index.js\n");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/01-hello/01-01/index.js"));
module.exports = __webpack_exports__;

})();