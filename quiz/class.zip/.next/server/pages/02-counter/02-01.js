"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/02-counter/02-01";
exports.ids = ["pages/02-counter/02-01"];
exports.modules = {

/***/ "./pages/02-counter/02-01/index.js":
/*!*****************************************!*\
  !*** ./pages/02-counter/02-01/index.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Counter01)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n\nfunction Counter01() {\n    function counter() {\n        const result = Number(document.getElementById(\"count\").innerText) + 1;\n        document.getElementById(\"count\").innerText = result;\n    }\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                id: \"count\",\n                children: \"0\"\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\cloubot\\\\Desktop\\\\quiz\\\\class\\\\pages\\\\02-counter\\\\02-01\\\\index.js\",\n                lineNumber: 8,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: counter,\n                children: \"Count Up\"\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\cloubot\\\\Desktop\\\\quiz\\\\class\\\\pages\\\\02-counter\\\\02-01\\\\index.js\",\n                lineNumber: 9,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"C:\\\\Users\\\\cloubot\\\\Desktop\\\\quiz\\\\class\\\\pages\\\\02-counter\\\\02-01\\\\index.js\",\n        lineNumber: 7,\n        columnNumber: 5\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8wMi1jb3VudGVyLzAyLTAxL2luZGV4LmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBZSxRQUFRLENBQUNBLFNBQVMsR0FBRyxDQUFDO2FBQzFCQyxPQUFPLEdBQUcsQ0FBQztRQUNsQixLQUFLLENBQUNDLE1BQU0sR0FBR0MsTUFBTSxDQUFDQyxRQUFRLENBQUNDLGNBQWMsQ0FBQyxDQUFPLFFBQUVDLFNBQVMsSUFBSSxDQUFDO1FBQ3JFRixRQUFRLENBQUNDLGNBQWMsQ0FBQyxDQUFPLFFBQUVDLFNBQVMsR0FBR0osTUFBTTtJQUNyRCxDQUFDO0lBQ0QsTUFBTSw2RUFDSEssQ0FBRzs7d0ZBQ0RBLENBQUc7Z0JBQUNDLEVBQUUsRUFBQyxDQUFPOzBCQUFDLENBQUM7Ozs7Ozt3RkFDaEJDLENBQU07Z0JBQUNDLE9BQU8sRUFBRVQsT0FBTzswQkFBRSxDQUFROzs7Ozs7Ozs7Ozs7QUFHeEMsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2NsYXNzLy4vcGFnZXMvMDItY291bnRlci8wMi0wMS9pbmRleC5qcz9mYmZkIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIENvdW50ZXIwMSgpIHtcclxuICBmdW5jdGlvbiBjb3VudGVyKCkge1xyXG4gICAgY29uc3QgcmVzdWx0ID0gTnVtYmVyKGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiY291bnRcIikuaW5uZXJUZXh0KSArIDE7XHJcbiAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImNvdW50XCIpLmlubmVyVGV4dCA9IHJlc3VsdDtcclxuICB9XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXY+XHJcbiAgICAgIDxkaXYgaWQ9XCJjb3VudFwiPjA8L2Rpdj5cclxuICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtjb3VudGVyfT5Db3VudCBVcDwvYnV0dG9uPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG4iXSwibmFtZXMiOlsiQ291bnRlcjAxIiwiY291bnRlciIsInJlc3VsdCIsIk51bWJlciIsImRvY3VtZW50IiwiZ2V0RWxlbWVudEJ5SWQiLCJpbm5lclRleHQiLCJkaXYiLCJpZCIsImJ1dHRvbiIsIm9uQ2xpY2siXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/02-counter/02-01/index.js\n");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/02-counter/02-01/index.js"));
module.exports = __webpack_exports__;

})();