"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/06-02-product-page/[pd]";
exports.ids = ["pages/06-02-product-page/[pd]"];
exports.modules = {

/***/ "./pages/06-02-product-page/[pd]/index.js":
/*!************************************************!*\
  !*** ./pages/06-02-product-page/[pd]/index.js ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ StaticRoutedPage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @apollo/client */ \"@apollo/client\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nconst FETCH_PRODUCT = _apollo_client__WEBPACK_IMPORTED_MODULE_1__.gql`\n  query fetchProduct($productId: ID) {\n    fetchProduct(productId : $productId) {\n      seller\n      name\n      detail\n      price\n    }\n  }\n`;\nfunction StaticRoutedPage() {\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();\n    const { data  } = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_1__.useQuery)(FETCH_PRODUCT, {\n        variables: {\n            productId: router.query.pd\n        }\n    });\n    console.log(data);\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                children: [\n                    \"판매자:\",\n                    data ? data.fetchProduct.seller : /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"span\", {\n                        children: \"loading...\"\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\cloubot\\\\Desktop\\\\codecamp_06_sejin\\\\quiz\\\\class\\\\pages\\\\06-02-product-page\\\\[pd]\\\\index.js\",\n                        lineNumber: 27,\n                        columnNumber: 52\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\Users\\\\cloubot\\\\Desktop\\\\codecamp_06_sejin\\\\quiz\\\\class\\\\pages\\\\06-02-product-page\\\\[pd]\\\\index.js\",\n                lineNumber: 27,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                children: [\n                    \"판매물품:\",\n                    data ? data.fetchProduct.name : /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"span\", {\n                        children: \"loading...\"\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\cloubot\\\\Desktop\\\\codecamp_06_sejin\\\\quiz\\\\class\\\\pages\\\\06-02-product-page\\\\[pd]\\\\index.js\",\n                        lineNumber: 28,\n                        columnNumber: 48\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\Users\\\\cloubot\\\\Desktop\\\\codecamp_06_sejin\\\\quiz\\\\class\\\\pages\\\\06-02-product-page\\\\[pd]\\\\index.js\",\n                lineNumber: 28,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                children: [\n                    \"상세설명:\",\n                    data ? data.fetchProduct.detail : /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"span\", {\n                        children: \"loading...\"\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\cloubot\\\\Desktop\\\\codecamp_06_sejin\\\\quiz\\\\class\\\\pages\\\\06-02-product-page\\\\[pd]\\\\index.js\",\n                        lineNumber: 29,\n                        columnNumber: 50\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\Users\\\\cloubot\\\\Desktop\\\\codecamp_06_sejin\\\\quiz\\\\class\\\\pages\\\\06-02-product-page\\\\[pd]\\\\index.js\",\n                lineNumber: 29,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                children: [\n                    \"가격:\",\n                    data ? data.fetchProduct.price : /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"span\", {\n                        children: \"loading...\"\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\cloubot\\\\Desktop\\\\codecamp_06_sejin\\\\quiz\\\\class\\\\pages\\\\06-02-product-page\\\\[pd]\\\\index.js\",\n                        lineNumber: 30,\n                        columnNumber: 47\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\Users\\\\cloubot\\\\Desktop\\\\codecamp_06_sejin\\\\quiz\\\\class\\\\pages\\\\06-02-product-page\\\\[pd]\\\\index.js\",\n                lineNumber: 30,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"C:\\\\Users\\\\cloubot\\\\Desktop\\\\codecamp_06_sejin\\\\quiz\\\\class\\\\pages\\\\06-02-product-page\\\\[pd]\\\\index.js\",\n        lineNumber: 25,\n        columnNumber: 5\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8wNi0wMi1wcm9kdWN0LXBhZ2UvW3BkXS9pbmRleC5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUE4QztBQUNQO0FBRXZDLEtBQUssQ0FBQ0csYUFBYSxHQUFHRiwrQ0FBRyxDQUFDOzs7Ozs7Ozs7QUFTMUI7QUFFZSxRQUFRLENBQUNHLGdCQUFnQixHQUFHLENBQUM7SUFDMUMsS0FBSyxDQUFDQyxNQUFNLEdBQUdILHNEQUFTO0lBRXhCLEtBQUssQ0FBQyxDQUFDLENBQUNJLElBQUksRUFBQyxDQUFDLEdBQUdOLHdEQUFRLENBQUNHLGFBQWEsRUFBRSxDQUFDO1FBQ3hDSSxTQUFTLEVBQUMsQ0FBQ0M7WUFBQUEsU0FBUyxFQUFDSCxNQUFNLENBQUNJLEtBQUssQ0FBQ0MsRUFBRTtRQUFBLENBQUM7SUFDdkMsQ0FBQztJQUVEQyxPQUFPLENBQUNDLEdBQUcsQ0FBQ04sSUFBSTtJQUVoQixNQUFNLDZFQUNITyxDQUFHOzt3RkFFREEsQ0FBRzs7b0JBQUMsQ0FBSTtvQkFBT1AsSUFBSSxHQUFHQSxJQUFJLENBQUNRLFlBQVksQ0FBQ0MsTUFBTSwrRUFBS0MsQ0FBSTtrQ0FBQyxDQUFVOzs7Ozs7Ozs7Ozs7d0ZBQzVESCxDQUFIOztvQkFBQyxDQUFLO29CQUFTUCxJQUFJLEdBQUNBLElBQUksQ0FBQ1EsWUFBWSxDQUFDRyxJQUFJLCtFQUFJRCxDQUFJO2tDQUFDLENBQVU7Ozs7Ozs7Ozs7Ozt3RkFDeERILENBQUw7O29CQUFDLENBQUs7b0JBQVNQLElBQUksR0FBQ0EsSUFBSSxDQUFDUSxZQUFZLENBQUNJLE1BQU0sK0VBQUlGLENBQUk7a0NBQUMsQ0FBVTs7Ozs7Ozs7Ozs7O3dGQUMxREgsQ0FBTDs7b0JBQUMsQ0FBRztvQkFBQ1AsSUFBSSxHQUFDQSxJQUFJLENBQUNRLFlBQVksQ0FBQ0ssS0FBSywrRUFBSUgsQ0FBSTtrQ0FBQyxDQUFVOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJOUQsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2NsYXNzLy4vcGFnZXMvMDYtMDItcHJvZHVjdC1wYWdlL1twZF0vaW5kZXguanM/YjU5NCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VRdWVyeSwgZ3FsIH0gZnJvbSBcIkBhcG9sbG8vY2xpZW50XCI7XHJcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCJuZXh0L3JvdXRlclwiO1xyXG5cclxuY29uc3QgRkVUQ0hfUFJPRFVDVCA9IGdxbGBcclxuICBxdWVyeSBmZXRjaFByb2R1Y3QoJHByb2R1Y3RJZDogSUQpIHtcclxuICAgIGZldGNoUHJvZHVjdChwcm9kdWN0SWQgOiAkcHJvZHVjdElkKSB7XHJcbiAgICAgIHNlbGxlclxyXG4gICAgICBuYW1lXHJcbiAgICAgIGRldGFpbFxyXG4gICAgICBwcmljZVxyXG4gICAgfVxyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFN0YXRpY1JvdXRlZFBhZ2UoKSB7XHJcbiAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XHJcblxyXG4gIGNvbnN0IHsgZGF0YSB9ID0gdXNlUXVlcnkoRkVUQ0hfUFJPRFVDVCwge1xyXG4gICAgdmFyaWFibGVzOntwcm9kdWN0SWQ6cm91dGVyLnF1ZXJ5LnBkfSxcclxuICB9KTtcclxuXHJcbiAgY29uc29sZS5sb2coZGF0YSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2PlxyXG4gICAgICBcclxuICAgICAgPGRpdj7tjJDrp6TsnpA6e2RhdGEgPyBkYXRhLmZldGNoUHJvZHVjdC5zZWxsZXIgOiAgPHNwYW4+bG9hZGluZy4uLjwvc3Bhbj59PC9kaXY+XHJcbiAgICAgIDxkaXY+7YyQ66ek66y87ZKIOntkYXRhP2RhdGEuZmV0Y2hQcm9kdWN0Lm5hbWU6ICA8c3Bhbj5sb2FkaW5nLi4uPC9zcGFuPn08L2Rpdj5cclxuICAgICAgPGRpdj7sg4HshLjshKTrqoU6e2RhdGE/ZGF0YS5mZXRjaFByb2R1Y3QuZGV0YWlsOiAgPHNwYW4+bG9hZGluZy4uLjwvc3Bhbj59PC9kaXY+XHJcbiAgICAgIDxkaXY+6rCA6rKpOntkYXRhP2RhdGEuZmV0Y2hQcm9kdWN0LnByaWNlOiAgPHNwYW4+bG9hZGluZy4uLjwvc3Bhbj59PC9kaXY+XHJcbiAgICAgIFxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG4iXSwibmFtZXMiOlsidXNlUXVlcnkiLCJncWwiLCJ1c2VSb3V0ZXIiLCJGRVRDSF9QUk9EVUNUIiwiU3RhdGljUm91dGVkUGFnZSIsInJvdXRlciIsImRhdGEiLCJ2YXJpYWJsZXMiLCJwcm9kdWN0SWQiLCJxdWVyeSIsInBkIiwiY29uc29sZSIsImxvZyIsImRpdiIsImZldGNoUHJvZHVjdCIsInNlbGxlciIsInNwYW4iLCJuYW1lIiwiZGV0YWlsIiwicHJpY2UiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/06-02-product-page/[pd]/index.js\n");

/***/ }),

/***/ "@apollo/client":
/*!*********************************!*\
  !*** external "@apollo/client" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/06-02-product-page/[pd]/index.js"));
module.exports = __webpack_exports__;

})();