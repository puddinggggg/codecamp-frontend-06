"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/03-randomnumber/03-01";
exports.ids = ["pages/03-randomnumber/03-01"];
exports.modules = {

/***/ "./pages/03-randomnumber/03-01/index.js":
/*!**********************************************!*\
  !*** ./pages/03-randomnumber/03-01/index.js ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Random01)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n\nfunction Random01() {\n    function random() {\n        const token = String(Math.floor(Math.random() * 1000000)).padStart(6, \"0\");\n        document.getElementById(\"randomNumber\").innerText = token;\n    }\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                id: \"randomNumber\",\n                children: \"000000\"\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\cloubot\\\\Desktop\\\\quiz\\\\class\\\\pages\\\\03-randomnumber\\\\03-01\\\\index.js\",\n                lineNumber: 8,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: random,\n                children: \"인증번호전송\"\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\cloubot\\\\Desktop\\\\quiz\\\\class\\\\pages\\\\03-randomnumber\\\\03-01\\\\index.js\",\n                lineNumber: 9,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"C:\\\\Users\\\\cloubot\\\\Desktop\\\\quiz\\\\class\\\\pages\\\\03-randomnumber\\\\03-01\\\\index.js\",\n        lineNumber: 7,\n        columnNumber: 5\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8wMy1yYW5kb21udW1iZXIvMDMtMDEvaW5kZXguanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUFlLFFBQVEsQ0FBQ0EsUUFBUSxHQUFHLENBQUM7YUFDekJDLE1BQU0sR0FBRyxDQUFDO1FBQ2pCLEtBQUssQ0FBQ0MsS0FBSyxHQUFHQyxNQUFNLENBQUNDLElBQUksQ0FBQ0MsS0FBSyxDQUFDRCxJQUFJLENBQUNILE1BQU0sS0FBRyxPQUFPLEdBQUdLLFFBQVEsQ0FBQyxDQUFDLEVBQUUsQ0FBRztRQUN2RUMsUUFBUSxDQUFDQyxjQUFjLENBQUMsQ0FBYyxlQUFFQyxTQUFTLEdBQUdQLEtBQUs7SUFDM0QsQ0FBQztJQUNELE1BQU0sNkVBQ0hRLENBQUc7O3dGQUNEQSxDQUFHO2dCQUFDQyxFQUFFLEVBQUMsQ0FBYzswQkFBQyxDQUFNOzs7Ozs7d0ZBQzVCQyxDQUFNO2dCQUFDQyxPQUFPLEVBQUVaLE1BQU07MEJBQUUsQ0FBTTs7Ozs7Ozs7Ozs7O0FBR3JDLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jbGFzcy8uL3BhZ2VzLzAzLXJhbmRvbW51bWJlci8wMy0wMS9pbmRleC5qcz82YjU5Il0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFJhbmRvbTAxKCkge1xyXG4gIGZ1bmN0aW9uIHJhbmRvbSgpIHtcclxuICAgIGNvbnN0IHRva2VuID0gU3RyaW5nKE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSoxMDAwMDAwKSkucGFkU3RhcnQoNiwgXCIwXCIpXHJcbiAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInJhbmRvbU51bWJlclwiKS5pbm5lclRleHQgPSB0b2tlbjtcclxuICB9XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXY+XHJcbiAgICAgIDxkaXYgaWQ9XCJyYW5kb21OdW1iZXJcIj4wMDAwMDA8L2Rpdj5cclxuICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtyYW5kb219PuyduOymneuyiO2YuOyghOyGoTwvYnV0dG9uPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG4iXSwibmFtZXMiOlsiUmFuZG9tMDEiLCJyYW5kb20iLCJ0b2tlbiIsIlN0cmluZyIsIk1hdGgiLCJmbG9vciIsInBhZFN0YXJ0IiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsImlubmVyVGV4dCIsImRpdiIsImlkIiwiYnV0dG9uIiwib25DbGljayJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/03-randomnumber/03-01/index.js\n");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/03-randomnumber/03-01/index.js"));
module.exports = __webpack_exports__;

})();