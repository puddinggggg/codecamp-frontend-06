//등록하기페이지
import ProductComponent from "../../../src/components/units/09-product-write/Product.container"
export default function ProductNewPage(){
    return(
       <ProductComponent isEdit={false}/>
    )
}