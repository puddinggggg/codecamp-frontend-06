export default function Presenter(props) {
  return <div>{props.child}</div>;
}
