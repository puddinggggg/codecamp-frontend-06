const [state, setState] = useState(0)

setState(qwer => qwer + 1)