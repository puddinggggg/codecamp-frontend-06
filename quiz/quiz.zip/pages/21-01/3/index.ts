["철수", "영희", "훈이", "맹구"].map((name, index) => {
    console.log(`${name}는 ${index}번째 칸에 들어있습니다.`)
})