/^\w+@\w+\.\w+$/.test("cute@pudding.com");
