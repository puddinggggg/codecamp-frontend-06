import BoardWrite from "../../src/components/units/07-01-routing/Routing.container";

export default function GraphqlMutationPage() {

  return (
    <BoardWrite/>
  );
}
