import DaumPostcode from "react-daum-postcode";

export default function Address() {
  return <DaumPostcode />;
}
