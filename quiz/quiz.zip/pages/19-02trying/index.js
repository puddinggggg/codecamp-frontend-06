import WriteBoard from "./container";

export default function ImageUpload() {
  return <WriteBoard />;
}
