"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/20-01";
exports.ids = ["pages/20-01"];
exports.modules = {

/***/ "./pages/20-01/index.tsx":
/*!*******************************!*\
  !*** ./pages/20-01/index.tsx ***!
  \*******************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ SearchBoard)\n/* harmony export */ });\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @apollo/client */ \"@apollo/client\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! uuid */ \"uuid\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lodash */ \"lodash\");\n/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__);\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([uuid__WEBPACK_IMPORTED_MODULE_2__]);\nuuid__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\nvar _jsxFileName = \"C:\\\\Users\\\\cloubot\\\\Desktop\\\\codecamp_06_sejin\\\\quiz\\\\pages\\\\20-01\\\\index.tsx\";\n\n\n\n\n\n\nconst FETCH_BOARDS = _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`\n  query fetchBoards($page: Int, $search: String) {\n    fetchBoards(page: $page, search: $search) {\n      writer\n      title\n      contents\n      _id\n    }\n  }\n`;\nconst Row = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`\n  border: 1px solid #dbdbdb;\n  display: flex;\n`;\nconst Column = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`\n  border: 1px solid #dbdbdb;\n  width: 50%;\n  text-align: center;\n`;\nconst Word = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().span)`\n  color: ${props => props.isMatched ? \"red\" : \"black\"};\n`;\nfunction SearchBoard() {\n  const {\n    0: keyword,\n    1: setKeyword\n  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(\"\");\n  const {\n    data,\n    refetch\n  } = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_0__.useQuery)(FETCH_BOARDS);\n\n  const getDebounce = lodash__WEBPACK_IMPORTED_MODULE_4___default().debounce(data => {\n    refetch({\n      search: data,\n      page: 1\n    });\n    setKeyword(data);\n  }, 500);\n\n  const onChangeSearch = event => {\n    getDebounce(event.target.value);\n  };\n\n  const onClickPage = e => {\n    refetch({\n      page: Number(e.target.id)\n    });\n  };\n\n  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(\"div\", {\n    children: [\"\\uAC80\\uC0C9\\uC5B4\\uC785\\uB825:\", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(\"input\", {\n      onChange: onChangeSearch,\n      type: \"text\"\n    }, void 0, false, {\n      fileName: _jsxFileName,\n      lineNumber: 59,\n      columnNumber: 7\n    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(Row, {\n      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(Column, {\n        children: \"\\uC791\\uC131\\uC790\"\n      }, void 0, false, {\n        fileName: _jsxFileName,\n        lineNumber: 61,\n        columnNumber: 9\n      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(Column, {\n        children: \"\\uC81C\\uBAA9\"\n      }, void 0, false, {\n        fileName: _jsxFileName,\n        lineNumber: 62,\n        columnNumber: 9\n      }, this)]\n    }, void 0, true, {\n      fileName: _jsxFileName,\n      lineNumber: 60,\n      columnNumber: 7\n    }, this), data === null || data === void 0 ? void 0 : data.fetchBoards.map(el => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(Row, {\n      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(Column, {\n        children: el.writer\n      }, void 0, false, {\n        fileName: _jsxFileName,\n        lineNumber: 66,\n        columnNumber: 11\n      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(Column, {\n        children: el.title.replaceAll(keyword, `¿¿¿${keyword}¿¿¿`).split(\"¿¿¿\").map(el => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(Word, {\n          isMatched: keyword === el,\n          children: el\n        }, (0,uuid__WEBPACK_IMPORTED_MODULE_2__.v4)(), false, {\n          fileName: _jsxFileName,\n          lineNumber: 72,\n          columnNumber: 17\n        }, this))\n      }, void 0, false, {\n        fileName: _jsxFileName,\n        lineNumber: 67,\n        columnNumber: 11\n      }, this)]\n    }, el._id, true, {\n      fileName: _jsxFileName,\n      lineNumber: 65,\n      columnNumber: 9\n    }, this)), new Array(10).fill(1).map((_, index) => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(\"span\", {\n      onClick: onClickPage,\n      id: String(index + 1),\n      children: index + 1\n    }, index + 1, false, {\n      fileName: _jsxFileName,\n      lineNumber: 80,\n      columnNumber: 9\n    }, this))]\n  }, void 0, true, {\n    fileName: _jsxFileName,\n    lineNumber: 57,\n    columnNumber: 5\n  }, this);\n}\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8yMC0wMS9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUtBO0FBQ0E7O0FBRUEsTUFBTU8sWUFBWSxHQUFHTiwrQ0FBSTtBQUN6QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FUQTtBQVVBLE1BQU1PLEdBQUcsR0FBR04sNERBQVc7QUFDdkI7QUFDQTtBQUNBLENBSEE7QUFJQSxNQUFNUSxNQUFNLEdBQUdSLDREQUFXO0FBQzFCO0FBQ0E7QUFDQTtBQUNBLENBSkE7QUFLQSxNQUFNUyxJQUFJLEdBQUdULDZEQUFZO0FBQ3pCLFdBQVlXLEtBQUQsSUFBbUJBLEtBQUssQ0FBQ0MsU0FBTixHQUFrQixLQUFsQixHQUEwQixPQUFTO0FBQ2pFLENBRkE7QUFRZSxTQUFTQyxXQUFULEdBQXVCO0FBQ3BDLFFBQU07QUFBQSxPQUFDQyxPQUFEO0FBQUEsT0FBVUM7QUFBVixNQUF3QlosK0NBQVEsQ0FBQyxFQUFELENBQXRDO0FBQ0EsUUFBTTtBQUFFYSxJQUFBQSxJQUFGO0FBQVFDLElBQUFBO0FBQVIsTUFBb0JuQix3REFBUSxDQUdoQ08sWUFIZ0MsQ0FBbEM7O0FBS0EsUUFBTWEsV0FBVyxHQUFHZCxzREFBQSxDQUFZWSxJQUFELElBQVU7QUFDdkNDLElBQUFBLE9BQU8sQ0FBQztBQUFFRyxNQUFBQSxNQUFNLEVBQUVKLElBQVY7QUFBZ0JLLE1BQUFBLElBQUksRUFBRTtBQUF0QixLQUFELENBQVA7QUFDQU4sSUFBQUEsVUFBVSxDQUFDQyxJQUFELENBQVY7QUFDRCxHQUhtQixFQUdqQixHQUhpQixDQUFwQjs7QUFJQSxRQUFNTSxjQUFjLEdBQUlDLEtBQUQsSUFBMEM7QUFDL0RMLElBQUFBLFdBQVcsQ0FBQ0ssS0FBSyxDQUFDQyxNQUFOLENBQWFDLEtBQWQsQ0FBWDtBQUNELEdBRkQ7O0FBR0EsUUFBTUMsV0FBVyxHQUFJQyxDQUFELElBQW9DO0FBQ3REVixJQUFBQSxPQUFPLENBQUM7QUFBRUksTUFBQUEsSUFBSSxFQUFFTyxNQUFNLENBQUNELENBQUMsQ0FBQ0gsTUFBRixDQUFTSyxFQUFWO0FBQWQsS0FBRCxDQUFQO0FBQ0QsR0FGRDs7QUFJQSxzQkFDRTtBQUFBLCtEQUVFO0FBQU8sY0FBUSxFQUFFUCxjQUFqQjtBQUFpQyxVQUFJLEVBQUM7QUFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUZGLGVBR0UsOERBQUMsR0FBRDtBQUFBLDhCQUNFLDhEQUFDLE1BQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FERixlQUVFLDhEQUFDLE1BQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFIRixFQU9HTixJQVBILGFBT0dBLElBUEgsdUJBT0dBLElBQUksQ0FBRWMsV0FBTixDQUFrQkMsR0FBbEIsQ0FBdUJDLEVBQUQsaUJBQ3JCLDhEQUFDLEdBQUQ7QUFBQSw4QkFDRSw4REFBQyxNQUFEO0FBQUEsa0JBQVNBLEVBQUUsQ0FBQ0M7QUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsZUFFRSw4REFBQyxNQUFEO0FBQUEsa0JBQ0dELEVBQUUsQ0FBQ0UsS0FBSCxDQUNFQyxVQURGLENBQ2FyQixPQURiLEVBQ3VCLE1BQUtBLE9BQVEsS0FEcEMsRUFFRXNCLEtBRkYsQ0FFUSxLQUZSLEVBR0VMLEdBSEYsQ0FHT0MsRUFBRCxpQkFDSCw4REFBQyxJQUFEO0FBQU0sbUJBQVMsRUFBRWxCLE9BQU8sS0FBS2tCLEVBQTdCO0FBQUEsb0JBQ0dBO0FBREgsV0FBc0M5Qix3Q0FBTSxFQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUpIO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUZGO0FBQUEsT0FBVThCLEVBQUUsQ0FBQ0ssR0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREQsQ0FQSCxFQXNCRyxJQUFJQyxLQUFKLENBQVUsRUFBVixFQUFjQyxJQUFkLENBQW1CLENBQW5CLEVBQXNCUixHQUF0QixDQUEwQixDQUFDM0IsQ0FBRCxFQUFJb0MsS0FBSixrQkFDekI7QUFBc0IsYUFBTyxFQUFFZCxXQUEvQjtBQUE0QyxRQUFFLEVBQUVlLE1BQU0sQ0FBQ0QsS0FBSyxHQUFHLENBQVQsQ0FBdEQ7QUFBQSxnQkFDR0EsS0FBSyxHQUFHO0FBRFgsT0FBV0EsS0FBSyxHQUFHLENBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERCxDQXRCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjtBQThCRCxDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xhc3MvLi9wYWdlcy8yMC0wMS9pbmRleC50c3g/YWVkNiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VRdWVyeSwgZ3FsIH0gZnJvbSBcIkBhcG9sbG8vY2xpZW50XCI7XHJcbmltcG9ydCBzdHlsZWQgZnJvbSBcIkBlbW90aW9uL3N0eWxlZFwiO1xyXG5pbXBvcnQgeyB2NCBhcyB1dWlkdjQgfSBmcm9tIFwidXVpZFwiO1xyXG5pbXBvcnQge1xyXG4gIElRdWVyeSxcclxuICBJUXVlcnlGZXRjaEJvYXJkc0FyZ3MsXHJcbn0gZnJvbSBcIi4uLy4uL3NyYy9jb21tb25zL3R5cGVzL2dlbmVyYXRlZC90eXBlc1wiO1xyXG5pbXBvcnQgeyBDaGFuZ2VFdmVudCwgdXNlU3RhdGUsIE1vdXNlRXZlbnQgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IF8gZnJvbSBcImxvZGFzaFwiO1xyXG5cclxuY29uc3QgRkVUQ0hfQk9BUkRTID0gZ3FsYFxyXG4gIHF1ZXJ5IGZldGNoQm9hcmRzKCRwYWdlOiBJbnQsICRzZWFyY2g6IFN0cmluZykge1xyXG4gICAgZmV0Y2hCb2FyZHMocGFnZTogJHBhZ2UsIHNlYXJjaDogJHNlYXJjaCkge1xyXG4gICAgICB3cml0ZXJcclxuICAgICAgdGl0bGVcclxuICAgICAgY29udGVudHNcclxuICAgICAgX2lkXHJcbiAgICB9XHJcbiAgfVxyXG5gO1xyXG5jb25zdCBSb3cgPSBzdHlsZWQuZGl2YFxyXG4gIGJvcmRlcjogMXB4IHNvbGlkICNkYmRiZGI7XHJcbiAgZGlzcGxheTogZmxleDtcclxuYDtcclxuY29uc3QgQ29sdW1uID0gc3R5bGVkLmRpdmBcclxuICBib3JkZXI6IDFweCBzb2xpZCAjZGJkYmRiO1xyXG4gIHdpZHRoOiA1MCU7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG5gO1xyXG5jb25zdCBXb3JkID0gc3R5bGVkLnNwYW5gXHJcbiAgY29sb3I6ICR7KHByb3BzOiBJUHJvcykgPT4gKHByb3BzLmlzTWF0Y2hlZCA/IFwicmVkXCIgOiBcImJsYWNrXCIpfTtcclxuYDtcclxuXHJcbmludGVyZmFjZSBJUHJvcyB7XHJcbiAgaXNNYXRjaGVkOiBib29sZWFuO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTZWFyY2hCb2FyZCgpIHtcclxuICBjb25zdCBba2V5d29yZCwgc2V0S2V5d29yZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCB7IGRhdGEsIHJlZmV0Y2ggfSA9IHVzZVF1ZXJ5PFxyXG4gICAgUGljazxJUXVlcnksIFwiZmV0Y2hCb2FyZHNcIj4sXHJcbiAgICBJUXVlcnlGZXRjaEJvYXJkc0FyZ3NcclxuICA+KEZFVENIX0JPQVJEUyk7XHJcblxyXG4gIGNvbnN0IGdldERlYm91bmNlID0gXy5kZWJvdW5jZSgoZGF0YSkgPT4ge1xyXG4gICAgcmVmZXRjaCh7IHNlYXJjaDogZGF0YSwgcGFnZTogMSB9KTtcclxuICAgIHNldEtleXdvcmQoZGF0YSk7XHJcbiAgfSwgNTAwKTtcclxuICBjb25zdCBvbkNoYW5nZVNlYXJjaCA9IChldmVudDogQ2hhbmdlRXZlbnQ8SFRNTElucHV0RWxlbWVudD4pID0+IHtcclxuICAgIGdldERlYm91bmNlKGV2ZW50LnRhcmdldC52YWx1ZSk7XHJcbiAgfTtcclxuICBjb25zdCBvbkNsaWNrUGFnZSA9IChlOiBNb3VzZUV2ZW50PEhUTUxTcGFuRWxlbWVudD4pID0+IHtcclxuICAgIHJlZmV0Y2goeyBwYWdlOiBOdW1iZXIoZS50YXJnZXQuaWQpIH0pO1xyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2PlxyXG4gICAgICDqsoDsg4nslrTsnoXroKU6XHJcbiAgICAgIDxpbnB1dCBvbkNoYW5nZT17b25DaGFuZ2VTZWFyY2h9IHR5cGU9XCJ0ZXh0XCIgLz5cclxuICAgICAgPFJvdz5cclxuICAgICAgICA8Q29sdW1uPuyekeyEseyekDwvQ29sdW1uPlxyXG4gICAgICAgIDxDb2x1bW4+7KCc66qpPC9Db2x1bW4+XHJcbiAgICAgIDwvUm93PlxyXG4gICAgICB7ZGF0YT8uZmV0Y2hCb2FyZHMubWFwKChlbCkgPT4gKFxyXG4gICAgICAgIDxSb3cga2V5PXtlbC5faWR9PlxyXG4gICAgICAgICAgPENvbHVtbj57ZWwud3JpdGVyfTwvQ29sdW1uPlxyXG4gICAgICAgICAgPENvbHVtbj5cclxuICAgICAgICAgICAge2VsLnRpdGxlXHJcbiAgICAgICAgICAgICAgLnJlcGxhY2VBbGwoa2V5d29yZCwgYMK/wr/CvyR7a2V5d29yZH3Cv8K/wr9gKVxyXG4gICAgICAgICAgICAgIC5zcGxpdChcIsK/wr/Cv1wiKVxyXG4gICAgICAgICAgICAgIC5tYXAoKGVsKSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8V29yZCBpc01hdGNoZWQ9e2tleXdvcmQgPT09IGVsfSBrZXk9e3V1aWR2NCgpfT5cclxuICAgICAgICAgICAgICAgICAge2VsfVxyXG4gICAgICAgICAgICAgICAgPC9Xb3JkPlxyXG4gICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgPC9Db2x1bW4+XHJcbiAgICAgICAgPC9Sb3c+XHJcbiAgICAgICkpfVxyXG4gICAgICB7bmV3IEFycmF5KDEwKS5maWxsKDEpLm1hcCgoXywgaW5kZXgpID0+IChcclxuICAgICAgICA8c3BhbiBrZXk9e2luZGV4ICsgMX0gb25DbGljaz17b25DbGlja1BhZ2V9IGlkPXtTdHJpbmcoaW5kZXggKyAxKX0+XHJcbiAgICAgICAgICB7aW5kZXggKyAxfVxyXG4gICAgICAgIDwvc3Bhbj5cclxuICAgICAgKSl9XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcbiJdLCJuYW1lcyI6WyJ1c2VRdWVyeSIsImdxbCIsInN0eWxlZCIsInY0IiwidXVpZHY0IiwidXNlU3RhdGUiLCJfIiwiRkVUQ0hfQk9BUkRTIiwiUm93IiwiZGl2IiwiQ29sdW1uIiwiV29yZCIsInNwYW4iLCJwcm9wcyIsImlzTWF0Y2hlZCIsIlNlYXJjaEJvYXJkIiwia2V5d29yZCIsInNldEtleXdvcmQiLCJkYXRhIiwicmVmZXRjaCIsImdldERlYm91bmNlIiwiZGVib3VuY2UiLCJzZWFyY2giLCJwYWdlIiwib25DaGFuZ2VTZWFyY2giLCJldmVudCIsInRhcmdldCIsInZhbHVlIiwib25DbGlja1BhZ2UiLCJlIiwiTnVtYmVyIiwiaWQiLCJmZXRjaEJvYXJkcyIsIm1hcCIsImVsIiwid3JpdGVyIiwidGl0bGUiLCJyZXBsYWNlQWxsIiwic3BsaXQiLCJfaWQiLCJBcnJheSIsImZpbGwiLCJpbmRleCIsIlN0cmluZyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/20-01/index.tsx\n");

/***/ }),

/***/ "@apollo/client":
/*!*********************************!*\
  !*** external "@apollo/client" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ "@emotion/styled":
/*!**********************************!*\
  !*** external "@emotion/styled" ***!
  \**********************************/
/***/ ((module) => {

module.exports = require("@emotion/styled");

/***/ }),

/***/ "lodash":
/*!*************************!*\
  !*** external "lodash" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("lodash");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "uuid":
/*!***********************!*\
  !*** external "uuid" ***!
  \***********************/
/***/ ((module) => {

module.exports = import("uuid");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/20-01/index.tsx"));
module.exports = __webpack_exports__;

})();