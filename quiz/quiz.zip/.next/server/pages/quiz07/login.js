"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/quiz07/login";
exports.ids = ["pages/quiz07/login"];
exports.modules = {

/***/ "./pages/quiz07/login/index.tsx":
/*!**************************************!*\
  !*** ./pages/quiz07/login/index.tsx ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ LoginPage)\n/* harmony export */ });\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @apollo/client */ \"@apollo/client\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! recoil */ \"recoil\");\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var _src_commons_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../src/commons/store */ \"./src/commons/store/index.ts\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__);\nvar _jsxFileName = \"C:\\\\Users\\\\cleve\\\\Desktop\\\\codecamp-frontend-06\\\\quiz\\\\pages\\\\quiz07\\\\login\\\\index.tsx\";\n\n\n\n\n // 토큰 만료시간이 한시간이 아니라 5초인 gql\n\n\nconst LOGIN_USER = _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`\n  mutation loginUser($email: String!, $password: String!) {\n    loginUsere(email: $email, password: $password) {\n      accessToken\n    }\n  }\n`;\nfunction LoginPage() {\n  const [, setAccessToken] = (0,recoil__WEBPACK_IMPORTED_MODULE_3__.useRecoilState)(_src_commons_store__WEBPACK_IMPORTED_MODULE_4__.accessTokenState);\n  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();\n  const {\n    0: email,\n    1: setEmail\n  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(\"\");\n  const {\n    0: password,\n    1: setPassword\n  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(\"\");\n  const [loginUser] = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_0__.useMutation)(LOGIN_USER);\n\n  const onChangeEmail = event => {\n    setEmail(event.target.value);\n  };\n\n  const onChangePassword = event => {\n    setPassword(event.target.value);\n  };\n\n  const onClickLogin = async () => {\n    const result = await loginUser({\n      variables: {\n        email,\n        password\n      }\n    });\n    const accessToken = result.data.loginUserExample.accessToken;\n    setAccessToken(accessToken);\n    alert(\"로그인성공\");\n    router.push(\"/quiz07/login-success\");\n  };\n\n  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(\"div\", {\n    children: [\"\\uC774\\uBA54\\uC77C:\", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(\"input\", {\n      onChange: onChangeEmail,\n      type: \"text\"\n    }, void 0, false, {\n      fileName: _jsxFileName,\n      lineNumber: 45,\n      columnNumber: 7\n    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(\"br\", {}, void 0, false, {\n      fileName: _jsxFileName,\n      lineNumber: 46,\n      columnNumber: 7\n    }, this), \"\\uBE44\\uBC00\\uBC88\\uD638:\", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(\"input\", {\n      onChange: onChangePassword,\n      type: \"password\"\n    }, void 0, false, {\n      fileName: _jsxFileName,\n      lineNumber: 48,\n      columnNumber: 7\n    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(\"br\", {}, void 0, false, {\n      fileName: _jsxFileName,\n      lineNumber: 49,\n      columnNumber: 7\n    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(\"button\", {\n      onClick: onClickLogin,\n      children: \" \\uB85C\\uADF8\\uC778\"\n    }, void 0, false, {\n      fileName: _jsxFileName,\n      lineNumber: 50,\n      columnNumber: 7\n    }, this)]\n  }, void 0, true, {\n    fileName: _jsxFileName,\n    lineNumber: 43,\n    columnNumber: 5\n  }, this);\n}//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9xdWl6MDcvbG9naW4vaW5kZXgudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtDQUdBOzs7QUFDQSxNQUFNTSxVQUFVLEdBQUdOLCtDQUFJO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQU5BO0FBUWUsU0FBU08sU0FBVCxHQUFxQjtBQUNsQyxRQUFNLEdBQUdDLGNBQUgsSUFBcUJKLHNEQUFjLENBQUNDLGdFQUFELENBQXpDO0FBQ0EsUUFBTUksTUFBTSxHQUFHUCxzREFBUyxFQUF4QjtBQUNBLFFBQU07QUFBQSxPQUFDUSxLQUFEO0FBQUEsT0FBUUM7QUFBUixNQUFvQlIsK0NBQVEsQ0FBQyxFQUFELENBQWxDO0FBQ0EsUUFBTTtBQUFBLE9BQUNTLFFBQUQ7QUFBQSxPQUFXQztBQUFYLE1BQTBCViwrQ0FBUSxDQUFDLEVBQUQsQ0FBeEM7QUFDQSxRQUFNLENBQUNXLFNBQUQsSUFBY2IsMkRBQVcsQ0FBQ0ssVUFBRCxDQUEvQjs7QUFFQSxRQUFNUyxhQUFhLEdBQUlDLEtBQUQsSUFBVztBQUMvQkwsSUFBQUEsUUFBUSxDQUFDSyxLQUFLLENBQUNDLE1BQU4sQ0FBYUMsS0FBZCxDQUFSO0FBQ0QsR0FGRDs7QUFHQSxRQUFNQyxnQkFBZ0IsR0FBSUgsS0FBRCxJQUFXO0FBQ2xDSCxJQUFBQSxXQUFXLENBQUNHLEtBQUssQ0FBQ0MsTUFBTixDQUFhQyxLQUFkLENBQVg7QUFDRCxHQUZEOztBQUdBLFFBQU1FLFlBQVksR0FBRyxZQUFZO0FBQy9CLFVBQU1DLE1BQU0sR0FBRyxNQUFNUCxTQUFTLENBQUM7QUFDN0JRLE1BQUFBLFNBQVMsRUFBRTtBQUNUWixRQUFBQSxLQURTO0FBRVRFLFFBQUFBO0FBRlM7QUFEa0IsS0FBRCxDQUE5QjtBQU1BLFVBQU1XLFdBQVcsR0FBR0YsTUFBTSxDQUFDRyxJQUFQLENBQVlDLGdCQUFaLENBQTZCRixXQUFqRDtBQUNBZixJQUFBQSxjQUFjLENBQUNlLFdBQUQsQ0FBZDtBQUNBRyxJQUFBQSxLQUFLLENBQUMsT0FBRCxDQUFMO0FBQ0FqQixJQUFBQSxNQUFNLENBQUNrQixJQUFQLENBQVksdUJBQVo7QUFDRCxHQVhEOztBQWFBLHNCQUNFO0FBQUEsbURBRUU7QUFBTyxjQUFRLEVBQUVaLGFBQWpCO0FBQWdDLFVBQUksRUFBQztBQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLFlBRkYsZUFHRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSEYsNENBS0U7QUFBTyxjQUFRLEVBQUVJLGdCQUFqQjtBQUFtQyxVQUFJLEVBQUM7QUFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUxGLGVBTUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU5GLGVBT0U7QUFBUSxhQUFPLEVBQUVDLFlBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7QUFXRCIsInNvdXJjZXMiOlsid2VicGFjazovL2NsYXNzLy4vcGFnZXMvcXVpejA3L2xvZ2luL2luZGV4LnRzeD9jNTFiIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGdxbCwgdXNlTXV0YXRpb24gfSBmcm9tIFwiQGFwb2xsby9jbGllbnRcIjtcclxuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIm5leHQvcm91dGVyXCI7XHJcbmltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZVJlY29pbFN0YXRlIH0gZnJvbSBcInJlY29pbFwiO1xyXG5pbXBvcnQgeyBhY2Nlc3NUb2tlblN0YXRlIH0gZnJvbSBcIi4uLy4uLy4uL3NyYy9jb21tb25zL3N0b3JlXCI7XHJcblxyXG4vLyDthqDtgbAg66eM66OM7Iuc6rCE7J20IO2VnOyLnOqwhOydtCDslYTri4jrnbwgNey0iOyduCBncWxcclxuY29uc3QgTE9HSU5fVVNFUiA9IGdxbGBcclxuICBtdXRhdGlvbiBsb2dpblVzZXIoJGVtYWlsOiBTdHJpbmchLCAkcGFzc3dvcmQ6IFN0cmluZyEpIHtcclxuICAgIGxvZ2luVXNlcmUoZW1haWw6ICRlbWFpbCwgcGFzc3dvcmQ6ICRwYXNzd29yZCkge1xyXG4gICAgICBhY2Nlc3NUb2tlblxyXG4gICAgfVxyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIExvZ2luUGFnZSgpIHtcclxuICBjb25zdCBbLCBzZXRBY2Nlc3NUb2tlbl0gPSB1c2VSZWNvaWxTdGF0ZShhY2Nlc3NUb2tlblN0YXRlKTtcclxuICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcclxuICBjb25zdCBbZW1haWwsIHNldEVtYWlsXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtwYXNzd29yZCwgc2V0UGFzc3dvcmRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2xvZ2luVXNlcl0gPSB1c2VNdXRhdGlvbihMT0dJTl9VU0VSKTtcclxuXHJcbiAgY29uc3Qgb25DaGFuZ2VFbWFpbCA9IChldmVudCkgPT4ge1xyXG4gICAgc2V0RW1haWwoZXZlbnQudGFyZ2V0LnZhbHVlKTtcclxuICB9O1xyXG4gIGNvbnN0IG9uQ2hhbmdlUGFzc3dvcmQgPSAoZXZlbnQpID0+IHtcclxuICAgIHNldFBhc3N3b3JkKGV2ZW50LnRhcmdldC52YWx1ZSk7XHJcbiAgfTtcclxuICBjb25zdCBvbkNsaWNrTG9naW4gPSBhc3luYyAoKSA9PiB7XHJcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBsb2dpblVzZXIoe1xyXG4gICAgICB2YXJpYWJsZXM6IHtcclxuICAgICAgICBlbWFpbCxcclxuICAgICAgICBwYXNzd29yZCxcclxuICAgICAgfSxcclxuICAgIH0pO1xyXG4gICAgY29uc3QgYWNjZXNzVG9rZW4gPSByZXN1bHQuZGF0YS5sb2dpblVzZXJFeGFtcGxlLmFjY2Vzc1Rva2VuO1xyXG4gICAgc2V0QWNjZXNzVG9rZW4oYWNjZXNzVG9rZW4pO1xyXG4gICAgYWxlcnQoXCLroZzqt7jsnbjshLHqs7VcIik7XHJcbiAgICByb3V0ZXIucHVzaChcIi9xdWl6MDcvbG9naW4tc3VjY2Vzc1wiKTtcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdj5cclxuICAgICAg7J2066mU7J28OlxyXG4gICAgICA8aW5wdXQgb25DaGFuZ2U9e29uQ2hhbmdlRW1haWx9IHR5cGU9XCJ0ZXh0XCIgLz5cclxuICAgICAgPGJyIC8+XHJcbiAgICAgIOu5hOuwgOuyiO2YuDpcclxuICAgICAgPGlucHV0IG9uQ2hhbmdlPXtvbkNoYW5nZVBhc3N3b3JkfSB0eXBlPVwicGFzc3dvcmRcIiAvPlxyXG4gICAgICA8YnIgLz5cclxuICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtvbkNsaWNrTG9naW59PiDroZzqt7jsnbg8L2J1dHRvbj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl0sIm5hbWVzIjpbImdxbCIsInVzZU11dGF0aW9uIiwidXNlUm91dGVyIiwidXNlU3RhdGUiLCJ1c2VSZWNvaWxTdGF0ZSIsImFjY2Vzc1Rva2VuU3RhdGUiLCJMT0dJTl9VU0VSIiwiTG9naW5QYWdlIiwic2V0QWNjZXNzVG9rZW4iLCJyb3V0ZXIiLCJlbWFpbCIsInNldEVtYWlsIiwicGFzc3dvcmQiLCJzZXRQYXNzd29yZCIsImxvZ2luVXNlciIsIm9uQ2hhbmdlRW1haWwiLCJldmVudCIsInRhcmdldCIsInZhbHVlIiwib25DaGFuZ2VQYXNzd29yZCIsIm9uQ2xpY2tMb2dpbiIsInJlc3VsdCIsInZhcmlhYmxlcyIsImFjY2Vzc1Rva2VuIiwiZGF0YSIsImxvZ2luVXNlckV4YW1wbGUiLCJhbGVydCIsInB1c2giXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/quiz07/login/index.tsx\n");

/***/ }),

/***/ "./src/commons/store/index.ts":
/*!************************************!*\
  !*** ./src/commons/store/index.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"isEditState\": () => (/* binding */ isEditState),\n/* harmony export */   \"accessTokenState\": () => (/* binding */ accessTokenState)\n/* harmony export */ });\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! recoil */ \"recoil\");\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_0__);\n\nconst isEditState = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({\n  key: \"isEditState\",\n  default: false\n});\nconst accessTokenState = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({\n  key: \"accessTokenState\",\n  default: \"\"\n});//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tbW9ucy9zdG9yZS9pbmRleC50cy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQUE7QUFFTyxNQUFNQyxXQUFXLEdBQUdELDRDQUFJLENBQUM7QUFDNUJFLEVBQUFBLEdBQUcsRUFBRSxhQUR1QjtBQUU1QkMsRUFBQUEsT0FBTyxFQUFFO0FBRm1CLENBQUQsQ0FBeEI7QUFJQSxNQUFNQyxnQkFBZ0IsR0FBR0osNENBQUksQ0FBQztBQUNqQ0UsRUFBQUEsR0FBRyxFQUFFLGtCQUQ0QjtBQUVqQ0MsRUFBQUEsT0FBTyxFQUFFO0FBRndCLENBQUQsQ0FBN0IiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jbGFzcy8uL3NyYy9jb21tb25zL3N0b3JlL2luZGV4LnRzPzNjYmYiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgYXRvbSB9IGZyb20gXCJyZWNvaWxcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBpc0VkaXRTdGF0ZSA9IGF0b20oe1xyXG4gICAga2V5OiBcImlzRWRpdFN0YXRlXCIsXHJcbiAgICBkZWZhdWx0OiBmYWxzZSxcclxufSlcclxuZXhwb3J0IGNvbnN0IGFjY2Vzc1Rva2VuU3RhdGUgPSBhdG9tKHtcclxuICAgIGtleTogXCJhY2Nlc3NUb2tlblN0YXRlXCIsXHJcbiAgICBkZWZhdWx0OiBcIlwiLFxyXG59KSJdLCJuYW1lcyI6WyJhdG9tIiwiaXNFZGl0U3RhdGUiLCJrZXkiLCJkZWZhdWx0IiwiYWNjZXNzVG9rZW5TdGF0ZSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/commons/store/index.ts\n");

/***/ }),

/***/ "@apollo/client":
/*!*********************************!*\
  !*** external "@apollo/client" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "recoil":
/*!*************************!*\
  !*** external "recoil" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("recoil");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/quiz07/login/index.tsx"));
module.exports = __webpack_exports__;

})();