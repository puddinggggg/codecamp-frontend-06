"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/27-01/pages/quiz06/main";
exports.ids = ["pages/27-01/pages/quiz06/main"];
exports.modules = {

/***/ "./pages/27-01/pages/quiz06/main/index.tsx":
/*!*************************************************!*\
  !*** ./pages/27-01/pages/quiz06/main/index.tsx ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ LoginPage)\n/* harmony export */ });\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @apollo/client */ \"@apollo/client\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! recoil */ \"recoil\");\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var _src_commons_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../../src/commons/store */ \"./src/commons/store/index.ts\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__);\nvar _jsxFileName = \"C:\\\\Users\\\\cicls_000\\\\Desktop\\\\codecamp-frontend-06\\\\quiz\\\\pages\\\\27-01\\\\pages\\\\quiz06\\\\main\\\\index.tsx\";\n\n\n\n\n\n\nconst LOGIN_USER = _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`\n  mutation loginUser($email: String!, $password: String!) {\n    loginUser(email: $email, password: $password) {\n      accessToken\n    }\n  }\n`;\nfunction LoginPage() {\n  const [, setAccessToken] = (0,recoil__WEBPACK_IMPORTED_MODULE_3__.useRecoilState)(_src_commons_store__WEBPACK_IMPORTED_MODULE_4__.accessTokenState);\n  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();\n  const {\n    0: email,\n    1: setEmail\n  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(\"\");\n  const {\n    0: password,\n    1: setPassword\n  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(\"\");\n  const [loginUser] = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_0__.useMutation)(LOGIN_USER);\n\n  const onChangeEmail = event => {\n    setEmail(event.target.value);\n  };\n\n  const onChangePassword = event => {\n    setPassword(event.target.value);\n  };\n\n  const onClickLogin = async () => {\n    const result = await loginUser({\n      variables: {\n        email,\n        password\n      }\n    });\n    const accessToken = result.data.loginUser.accessToken;\n    setAccessToken(accessToken);\n    localStorage.setItem(\"accessToken\", accessToken); // alert(\"로그인성공\");\n\n    const baskets = JSON.parse(localStorage.getItem(\"baskets\") || \"[]\");\n\n    if (baskets.length > 0) {\n      alert(\"비회원 장바구니 존재. 이동?\");\n      router.push(\"../quiz06/basket\");\n      return;\n    }\n  };\n\n  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(\"div\", {\n    children: [\"\\uC774\\uBA54\\uC77C:\", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(\"input\", {\n      onChange: onChangeEmail,\n      type: \"text\"\n    }, void 0, false, {\n      fileName: _jsxFileName,\n      lineNumber: 54,\n      columnNumber: 7\n    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(\"br\", {}, void 0, false, {\n      fileName: _jsxFileName,\n      lineNumber: 55,\n      columnNumber: 7\n    }, this), \"\\uBE44\\uBC00\\uBC88\\uD638:\", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(\"input\", {\n      onChange: onChangePassword,\n      type: \"password\"\n    }, void 0, false, {\n      fileName: _jsxFileName,\n      lineNumber: 57,\n      columnNumber: 7\n    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(\"br\", {}, void 0, false, {\n      fileName: _jsxFileName,\n      lineNumber: 58,\n      columnNumber: 7\n    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(\"button\", {\n      onClick: onClickLogin,\n      children: \" \\uB85C\\uADF8\\uC778\"\n    }, void 0, false, {\n      fileName: _jsxFileName,\n      lineNumber: 59,\n      columnNumber: 7\n    }, this)]\n  }, void 0, true, {\n    fileName: _jsxFileName,\n    lineNumber: 52,\n    columnNumber: 5\n  }, this);\n}//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8yNy0wMS9wYWdlcy9xdWl6MDYvbWFpbi9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsTUFBTU0sVUFBVSxHQUFHTiwrQ0FBSTtBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FOQTtBQVFlLFNBQVNPLFNBQVQsR0FBcUI7QUFDbEMsUUFBTSxHQUFHQyxjQUFILElBQXFCSixzREFBYyxDQUFDQyxnRUFBRCxDQUF6QztBQUNBLFFBQU1JLE1BQU0sR0FBR1Asc0RBQVMsRUFBeEI7QUFDQSxRQUFNO0FBQUEsT0FBQ1EsS0FBRDtBQUFBLE9BQVFDO0FBQVIsTUFBb0JSLCtDQUFRLENBQUMsRUFBRCxDQUFsQztBQUNBLFFBQU07QUFBQSxPQUFDUyxRQUFEO0FBQUEsT0FBV0M7QUFBWCxNQUEwQlYsK0NBQVEsQ0FBQyxFQUFELENBQXhDO0FBQ0EsUUFBTSxDQUFDVyxTQUFELElBQWNiLDJEQUFXLENBQUNLLFVBQUQsQ0FBL0I7O0FBRUEsUUFBTVMsYUFBYSxHQUFJQyxLQUFELElBQVc7QUFDL0JMLElBQUFBLFFBQVEsQ0FBQ0ssS0FBSyxDQUFDQyxNQUFOLENBQWFDLEtBQWQsQ0FBUjtBQUNELEdBRkQ7O0FBR0EsUUFBTUMsZ0JBQWdCLEdBQUlILEtBQUQsSUFBVztBQUNsQ0gsSUFBQUEsV0FBVyxDQUFDRyxLQUFLLENBQUNDLE1BQU4sQ0FBYUMsS0FBZCxDQUFYO0FBQ0QsR0FGRDs7QUFLQSxRQUFNRSxZQUFZLEdBQUcsWUFBWTtBQUMvQixVQUFNQyxNQUFNLEdBQUcsTUFBTVAsU0FBUyxDQUFDO0FBQzdCUSxNQUFBQSxTQUFTLEVBQUU7QUFDVFosUUFBQUEsS0FEUztBQUVURSxRQUFBQTtBQUZTO0FBRGtCLEtBQUQsQ0FBOUI7QUFNQSxVQUFNVyxXQUFXLEdBQUdGLE1BQU0sQ0FBQ0csSUFBUCxDQUFZVixTQUFaLENBQXNCUyxXQUExQztBQUNBZixJQUFBQSxjQUFjLENBQUNlLFdBQUQsQ0FBZDtBQUNBRSxJQUFBQSxZQUFZLENBQUNDLE9BQWIsQ0FBcUIsYUFBckIsRUFBb0NILFdBQXBDLEVBVCtCLENBVS9COztBQUNBLFVBQU1JLE9BQU8sR0FBR0MsSUFBSSxDQUFDQyxLQUFMLENBQVdKLFlBQVksQ0FBQ0ssT0FBYixDQUFxQixTQUFyQixLQUFtQyxJQUE5QyxDQUFoQjs7QUFFQSxRQUFHSCxPQUFPLENBQUNJLE1BQVIsR0FBZSxDQUFsQixFQUFxQjtBQUN6QkMsTUFBQUEsS0FBSyxDQUFDLGtCQUFELENBQUw7QUFDQXZCLE1BQUFBLE1BQU0sQ0FBQ3dCLElBQVAsQ0FBWSxrQkFBWjtBQUNBO0FBQ0s7QUFFRixHQW5CRDs7QUFxQkEsc0JBQ0U7QUFBQSxtREFFRTtBQUFPLGNBQVEsRUFBRWxCLGFBQWpCO0FBQWdDLFVBQUksRUFBQztBQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLFlBRkYsZUFHRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSEYsNENBS0U7QUFBTyxjQUFRLEVBQUVJLGdCQUFqQjtBQUFtQyxVQUFJLEVBQUM7QUFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUxGLGVBTUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU5GLGVBT0U7QUFBUSxhQUFPLEVBQUVDLFlBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7QUFXRCIsInNvdXJjZXMiOlsid2VicGFjazovL2NsYXNzLy4vcGFnZXMvMjctMDEvcGFnZXMvcXVpejA2L21haW4vaW5kZXgudHN4PzE5OTAiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgZ3FsLCB1c2VNdXRhdGlvbiB9IGZyb20gXCJAYXBvbGxvL2NsaWVudFwiO1xyXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwibmV4dC9yb3V0ZXJcIjtcclxuaW1wb3J0IHsgIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZVJlY29pbFN0YXRlIH0gZnJvbSBcInJlY29pbFwiO1xyXG5pbXBvcnQgeyBhY2Nlc3NUb2tlblN0YXRlIH0gZnJvbSBcIi4uLy4uLy4uLy4uLy4uL3NyYy9jb21tb25zL3N0b3JlXCI7XHJcblxyXG5jb25zdCBMT0dJTl9VU0VSID0gZ3FsYFxyXG4gIG11dGF0aW9uIGxvZ2luVXNlcigkZW1haWw6IFN0cmluZyEsICRwYXNzd29yZDogU3RyaW5nISkge1xyXG4gICAgbG9naW5Vc2VyKGVtYWlsOiAkZW1haWwsIHBhc3N3b3JkOiAkcGFzc3dvcmQpIHtcclxuICAgICAgYWNjZXNzVG9rZW5cclxuICAgIH1cclxuICB9XHJcbmA7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBMb2dpblBhZ2UoKSB7XHJcbiAgY29uc3QgWywgc2V0QWNjZXNzVG9rZW5dID0gdXNlUmVjb2lsU3RhdGUoYWNjZXNzVG9rZW5TdGF0ZSk7XHJcbiAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XHJcbiAgY29uc3QgW2VtYWlsLCBzZXRFbWFpbF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbcGFzc3dvcmQsIHNldFBhc3N3b3JkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtsb2dpblVzZXJdID0gdXNlTXV0YXRpb24oTE9HSU5fVVNFUik7XHJcbiAgXHJcbiAgY29uc3Qgb25DaGFuZ2VFbWFpbCA9IChldmVudCkgPT4ge1xyXG4gICAgc2V0RW1haWwoZXZlbnQudGFyZ2V0LnZhbHVlKTtcclxuICB9O1xyXG4gIGNvbnN0IG9uQ2hhbmdlUGFzc3dvcmQgPSAoZXZlbnQpID0+IHtcclxuICAgIHNldFBhc3N3b3JkKGV2ZW50LnRhcmdldC52YWx1ZSk7XHJcbiAgfTtcclxuXHJcblxyXG4gIGNvbnN0IG9uQ2xpY2tMb2dpbiA9IGFzeW5jICgpID0+IHtcclxuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGxvZ2luVXNlcih7XHJcbiAgICAgIHZhcmlhYmxlczoge1xyXG4gICAgICAgIGVtYWlsLFxyXG4gICAgICAgIHBhc3N3b3JkLFxyXG4gICAgICB9LFxyXG4gICAgfSk7XHJcbiAgICBjb25zdCBhY2Nlc3NUb2tlbiA9IHJlc3VsdC5kYXRhLmxvZ2luVXNlci5hY2Nlc3NUb2tlbjtcclxuICAgIHNldEFjY2Vzc1Rva2VuKGFjY2Vzc1Rva2VuKTtcclxuICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwiYWNjZXNzVG9rZW5cIiwgYWNjZXNzVG9rZW4pO1xyXG4gICAgLy8gYWxlcnQoXCLroZzqt7jsnbjshLHqs7VcIik7XHJcbiAgICBjb25zdCBiYXNrZXRzID0gSlNPTi5wYXJzZShsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImJhc2tldHNcIikgfHwgXCJbXVwiKVxyXG5cclxuICAgIGlmKGJhc2tldHMubGVuZ3RoPjApIHtcclxuYWxlcnQoXCLruYTtmozsm5Ag7J6l67CU6rWs64uIIOyhtOyerC4g7J2064+ZP1wiKVxyXG5yb3V0ZXIucHVzaChcIi4uL3F1aXowNi9iYXNrZXRcIilcclxucmV0dXJuXHJcbiAgICB9XHJcbiAgICBcclxuICB9O1xyXG4gIFxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2PlxyXG4gICAgICDsnbTrqZTsnbw6XHJcbiAgICAgIDxpbnB1dCBvbkNoYW5nZT17b25DaGFuZ2VFbWFpbH0gdHlwZT1cInRleHRcIiAvPlxyXG4gICAgICA8YnIgLz5cclxuICAgICAg67mE67CA67KI7Zi4OlxyXG4gICAgICA8aW5wdXQgb25DaGFuZ2U9e29uQ2hhbmdlUGFzc3dvcmR9IHR5cGU9XCJwYXNzd29yZFwiIC8+XHJcbiAgICAgIDxiciAvPlxyXG4gICAgICA8YnV0dG9uIG9uQ2xpY2s9e29uQ2xpY2tMb2dpbn0+IOuhnOq3uOyduDwvYnV0dG9uPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG4iXSwibmFtZXMiOlsiZ3FsIiwidXNlTXV0YXRpb24iLCJ1c2VSb3V0ZXIiLCJ1c2VTdGF0ZSIsInVzZVJlY29pbFN0YXRlIiwiYWNjZXNzVG9rZW5TdGF0ZSIsIkxPR0lOX1VTRVIiLCJMb2dpblBhZ2UiLCJzZXRBY2Nlc3NUb2tlbiIsInJvdXRlciIsImVtYWlsIiwic2V0RW1haWwiLCJwYXNzd29yZCIsInNldFBhc3N3b3JkIiwibG9naW5Vc2VyIiwib25DaGFuZ2VFbWFpbCIsImV2ZW50IiwidGFyZ2V0IiwidmFsdWUiLCJvbkNoYW5nZVBhc3N3b3JkIiwib25DbGlja0xvZ2luIiwicmVzdWx0IiwidmFyaWFibGVzIiwiYWNjZXNzVG9rZW4iLCJkYXRhIiwibG9jYWxTdG9yYWdlIiwic2V0SXRlbSIsImJhc2tldHMiLCJKU09OIiwicGFyc2UiLCJnZXRJdGVtIiwibGVuZ3RoIiwiYWxlcnQiLCJwdXNoIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/27-01/pages/quiz06/main/index.tsx\n");

/***/ }),

/***/ "./src/commons/store/index.ts":
/*!************************************!*\
  !*** ./src/commons/store/index.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"isEditState\": () => (/* binding */ isEditState),\n/* harmony export */   \"accessTokenState\": () => (/* binding */ accessTokenState)\n/* harmony export */ });\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! recoil */ \"recoil\");\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_0__);\n\nconst isEditState = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({\n  key: \"isEditState\",\n  default: false\n});\nconst accessTokenState = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({\n  key: \"accessTokenState\",\n  default: \"\"\n});//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tbW9ucy9zdG9yZS9pbmRleC50cy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQUE7QUFFTyxNQUFNQyxXQUFXLEdBQUdELDRDQUFJLENBQUM7QUFDNUJFLEVBQUFBLEdBQUcsRUFBRSxhQUR1QjtBQUU1QkMsRUFBQUEsT0FBTyxFQUFFO0FBRm1CLENBQUQsQ0FBeEI7QUFJQSxNQUFNQyxnQkFBZ0IsR0FBR0osNENBQUksQ0FBQztBQUNqQ0UsRUFBQUEsR0FBRyxFQUFFLGtCQUQ0QjtBQUVqQ0MsRUFBQUEsT0FBTyxFQUFFO0FBRndCLENBQUQsQ0FBN0IiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jbGFzcy8uL3NyYy9jb21tb25zL3N0b3JlL2luZGV4LnRzPzNjYmYiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgYXRvbSB9IGZyb20gXCJyZWNvaWxcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBpc0VkaXRTdGF0ZSA9IGF0b20oe1xyXG4gICAga2V5OiBcImlzRWRpdFN0YXRlXCIsXHJcbiAgICBkZWZhdWx0OiBmYWxzZSxcclxufSlcclxuZXhwb3J0IGNvbnN0IGFjY2Vzc1Rva2VuU3RhdGUgPSBhdG9tKHtcclxuICAgIGtleTogXCJhY2Nlc3NUb2tlblN0YXRlXCIsXHJcbiAgICBkZWZhdWx0OiBcIlwiLFxyXG59KSJdLCJuYW1lcyI6WyJhdG9tIiwiaXNFZGl0U3RhdGUiLCJrZXkiLCJkZWZhdWx0IiwiYWNjZXNzVG9rZW5TdGF0ZSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/commons/store/index.ts\n");

/***/ }),

/***/ "@apollo/client":
/*!*********************************!*\
  !*** external "@apollo/client" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "recoil":
/*!*************************!*\
  !*** external "recoil" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("recoil");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/27-01/pages/quiz06/main/index.tsx"));
module.exports = __webpack_exports__;

})();