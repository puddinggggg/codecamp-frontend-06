"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/27test";
exports.ids = ["pages/27test"];
exports.modules = {

/***/ "./pages/27test/boardsItem/index.tsx":
/*!*******************************************!*\
  !*** ./pages/27test/boardsItem/index.tsx ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ BoardItems)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);\nconst _excluded = [\"__typename\"];\nvar _jsxFileName = \"C:\\\\Users\\\\cicls_000\\\\Desktop\\\\codecamp-frontend-06\\\\quiz\\\\pages\\\\27test\\\\boardsItem\\\\index.tsx\";\n\nfunction _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }\n\nfunction _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }\n\n\n\nfunction BoardItems(props) {\n  const {\n    0: isAlready,\n    1: setIsAlready\n  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);\n\n  const onClickBasket = el => () => {\n    // 기존 장바구니 가져오기\n    const baskets = JSON.parse(localStorage.getItem(\"baskets\") || \"[]\"); // 이미 담겼는지 확인하기\n\n    const temp = baskets.filter(basketEl => basketEl._id === el._id);\n\n    if (temp.length > 0) {\n      alert(\"이미 담으신물품입니다!\");\n      return;\n    }\n\n    const {\n      __typename\n    } = el,\n          newEl = _objectWithoutProperties(el, _excluded);\n\n    baskets.push(newEl);\n    localStorage.setItem(\"baskets\", JSON.stringify(baskets));\n    setIsAlready(true);\n  };\n\n  const onClickDelete = el => () => {\n    // 기존 장바구니 가져오기\n    const baskets = JSON.parse(localStorage.getItem(\"baskets\") || \"[]\");\n    const newBaskets = baskets.filter(basketEl => basketEl._id !== el._id);\n    setIsAlready(false);\n    localStorage.setItem(\"baskets\", JSON.stringify(newBaskets));\n  };\n\n  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(\"div\", {\n    children: [\" \", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(\"div\", {\n      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(\"span\", {\n        children: props.el.title\n      }, void 0, false, {\n        fileName: _jsxFileName,\n        lineNumber: 43,\n        columnNumber: 9\n      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(\"span\", {\n        children: props.el.writer\n      }, void 0, false, {\n        fileName: _jsxFileName,\n        lineNumber: 44,\n        columnNumber: 9\n      }, this), isAlready ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(\"button\", {\n        onClick: onClickDelete(props.el),\n        children: \"\\uB2F4\\uAE30\\uCDE8\\uC18C\"\n      }, void 0, false, {\n        fileName: _jsxFileName,\n        lineNumber: 46,\n        columnNumber: 11\n      }, this) : /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(\"button\", {\n        onClick: onClickBasket(props.el),\n        children: \"\\uC7A5\\uBC14\\uAD6C\\uB2C8\\uB2F4\\uAE30\"\n      }, void 0, false, {\n        fileName: _jsxFileName,\n        lineNumber: 48,\n        columnNumber: 11\n      }, this)]\n    }, props.el._id, true, {\n      fileName: _jsxFileName,\n      lineNumber: 42,\n      columnNumber: 7\n    }, this)]\n  }, void 0, true, {\n    fileName: _jsxFileName,\n    lineNumber: 40,\n    columnNumber: 5\n  }, this);\n}//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8yN3Rlc3QvYm9hcmRzSXRlbS9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7O0FBUWUsU0FBU0MsVUFBVCxDQUFvQkMsS0FBcEIsRUFBdUM7QUFDcEQsUUFBTTtBQUFBLE9BQUNDLFNBQUQ7QUFBQSxPQUFZQztBQUFaLE1BQTRCSiwrQ0FBUSxDQUFDLEtBQUQsQ0FBMUM7O0FBRUEsUUFBTUssYUFBYSxHQUFJQyxFQUFELElBQWdCLE1BQU07QUFDMUM7QUFDQSxVQUFNQyxPQUFPLEdBQUdDLElBQUksQ0FBQ0MsS0FBTCxDQUFXQyxZQUFZLENBQUNDLE9BQWIsQ0FBcUIsU0FBckIsS0FBbUMsSUFBOUMsQ0FBaEIsQ0FGMEMsQ0FJMUM7O0FBQ0EsVUFBTUMsSUFBSSxHQUFHTCxPQUFPLENBQUNNLE1BQVIsQ0FBZ0JDLFFBQUQsSUFBc0JBLFFBQVEsQ0FBQ0MsR0FBVCxLQUFpQlQsRUFBRSxDQUFDUyxHQUF6RCxDQUFiOztBQUNBLFFBQUlILElBQUksQ0FBQ0ksTUFBTCxHQUFjLENBQWxCLEVBQXFCO0FBQ25CQyxNQUFBQSxLQUFLLENBQUMsY0FBRCxDQUFMO0FBQ0E7QUFDRDs7QUFFRCxVQUFNO0FBQUVDLE1BQUFBO0FBQUYsUUFBMkJaLEVBQWpDO0FBQUEsVUFBdUJhLEtBQXZCLDRCQUFpQ2IsRUFBakM7O0FBQ0FDLElBQUFBLE9BQU8sQ0FBQ2EsSUFBUixDQUFhRCxLQUFiO0FBQ0FULElBQUFBLFlBQVksQ0FBQ1csT0FBYixDQUFxQixTQUFyQixFQUFnQ2IsSUFBSSxDQUFDYyxTQUFMLENBQWVmLE9BQWYsQ0FBaEM7QUFDQUgsSUFBQUEsWUFBWSxDQUFDLElBQUQsQ0FBWjtBQUNELEdBZkQ7O0FBaUJBLFFBQU1tQixhQUFhLEdBQUlqQixFQUFELElBQWdCLE1BQU07QUFDMUM7QUFDQSxVQUFNQyxPQUFPLEdBQUdDLElBQUksQ0FBQ0MsS0FBTCxDQUFXQyxZQUFZLENBQUNDLE9BQWIsQ0FBcUIsU0FBckIsS0FBbUMsSUFBOUMsQ0FBaEI7QUFFQSxVQUFNYSxVQUFVLEdBQUdqQixPQUFPLENBQUNNLE1BQVIsQ0FDaEJDLFFBQUQsSUFBc0JBLFFBQVEsQ0FBQ0MsR0FBVCxLQUFpQlQsRUFBRSxDQUFDUyxHQUR6QixDQUFuQjtBQUdBWCxJQUFBQSxZQUFZLENBQUMsS0FBRCxDQUFaO0FBQ0FNLElBQUFBLFlBQVksQ0FBQ1csT0FBYixDQUFxQixTQUFyQixFQUFnQ2IsSUFBSSxDQUFDYyxTQUFMLENBQWVFLFVBQWYsQ0FBaEM7QUFDRCxHQVREOztBQVVBLHNCQUNFO0FBQUEsZUFDRyxHQURILGVBRUU7QUFBQSw4QkFDRTtBQUFBLGtCQUFPdEIsS0FBSyxDQUFDSSxFQUFOLENBQVNtQjtBQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsZUFFRTtBQUFBLGtCQUFPdkIsS0FBSyxDQUFDSSxFQUFOLENBQVNvQjtBQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRkYsRUFHR3ZCLFNBQVMsZ0JBQ1I7QUFBUSxlQUFPLEVBQUVvQixhQUFhLENBQUNyQixLQUFLLENBQUNJLEVBQVAsQ0FBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FEUSxnQkFHUjtBQUFRLGVBQU8sRUFBRUQsYUFBYSxDQUFDSCxLQUFLLENBQUNJLEVBQVAsQ0FBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FOSjtBQUFBLE9BQVVKLEtBQUssQ0FBQ0ksRUFBTixDQUFTUyxHQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7QUFjRCIsInNvdXJjZXMiOlsid2VicGFjazovL2NsYXNzLy4vcGFnZXMvMjd0ZXN0L2JvYXJkc0l0ZW0vaW5kZXgudHN4P2E2MDAiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgSUJvYXJkIH0gZnJvbSBcIi4uLy4uLy4uLy4uL3NyYy9jb21tb25zL3R5cGVzL2dlbmVyYXRlZC90eXBlc1wiO1xyXG5cclxuaW50ZXJmYWNlIElJdGVtUHJvcHMge1xyXG4gIGRhdGE/OiBhbnk7XHJcbiAgaW5kZXg6IG51bWJlcjtcclxuICBlbDogSUJvYXJkO1xyXG59XHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEJvYXJkSXRlbXMocHJvcHM6IElJdGVtUHJvcHMpIHtcclxuICBjb25zdCBbaXNBbHJlYWR5LCBzZXRJc0FscmVhZHldID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICBjb25zdCBvbkNsaWNrQmFza2V0ID0gKGVsOiBJQm9hcmQpID0+ICgpID0+IHtcclxuICAgIC8vIOq4sOyhtCDsnqXrsJTqtazri4gg6rCA7KC47Jik6riwXHJcbiAgICBjb25zdCBiYXNrZXRzID0gSlNPTi5wYXJzZShsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImJhc2tldHNcIikgfHwgXCJbXVwiKTtcclxuXHJcbiAgICAvLyDsnbTrr7gg64u06rK864qU7KeAIO2ZleyduO2VmOq4sFxyXG4gICAgY29uc3QgdGVtcCA9IGJhc2tldHMuZmlsdGVyKChiYXNrZXRFbDogSUJvYXJkKSA9PiBiYXNrZXRFbC5faWQgPT09IGVsLl9pZCk7XHJcbiAgICBpZiAodGVtcC5sZW5ndGggPiAwKSB7XHJcbiAgICAgIGFsZXJ0KFwi7J2066+4IOuLtOycvOyLoOusvO2SiOyeheuLiOuLpCFcIik7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCB7IF9fdHlwZW5hbWUsIC4uLm5ld0VsIH0gPSBlbDtcclxuICAgIGJhc2tldHMucHVzaChuZXdFbCk7XHJcbiAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImJhc2tldHNcIiwgSlNPTi5zdHJpbmdpZnkoYmFza2V0cykpO1xyXG4gICAgc2V0SXNBbHJlYWR5KHRydWUpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IG9uQ2xpY2tEZWxldGUgPSAoZWw6IElCb2FyZCkgPT4gKCkgPT4ge1xyXG4gICAgLy8g6riw7KG0IOyepeuwlOq1rOuLiCDqsIDsoLjsmKTquLBcclxuICAgIGNvbnN0IGJhc2tldHMgPSBKU09OLnBhcnNlKGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiYmFza2V0c1wiKSB8fCBcIltdXCIpO1xyXG5cclxuICAgIGNvbnN0IG5ld0Jhc2tldHMgPSBiYXNrZXRzLmZpbHRlcihcclxuICAgICAgKGJhc2tldEVsOiBJQm9hcmQpID0+IGJhc2tldEVsLl9pZCAhPT0gZWwuX2lkXHJcbiAgICApO1xyXG4gICAgc2V0SXNBbHJlYWR5KGZhbHNlKTtcclxuICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwiYmFza2V0c1wiLCBKU09OLnN0cmluZ2lmeShuZXdCYXNrZXRzKSk7XHJcbiAgfTtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdj5cclxuICAgICAge1wiIFwifVxyXG4gICAgICA8ZGl2IGtleT17cHJvcHMuZWwuX2lkfT5cclxuICAgICAgICA8c3Bhbj57cHJvcHMuZWwudGl0bGV9PC9zcGFuPlxyXG4gICAgICAgIDxzcGFuPntwcm9wcy5lbC53cml0ZXJ9PC9zcGFuPlxyXG4gICAgICAgIHtpc0FscmVhZHkgPyAoXHJcbiAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e29uQ2xpY2tEZWxldGUocHJvcHMuZWwpfT7ri7TquLDst6jshow8L2J1dHRvbj5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtvbkNsaWNrQmFza2V0KHByb3BzLmVsKX0+7J6l67CU6rWs64uI64u06riwPC9idXR0b24+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59Il0sIm5hbWVzIjpbInVzZVN0YXRlIiwiQm9hcmRJdGVtcyIsInByb3BzIiwiaXNBbHJlYWR5Iiwic2V0SXNBbHJlYWR5Iiwib25DbGlja0Jhc2tldCIsImVsIiwiYmFza2V0cyIsIkpTT04iLCJwYXJzZSIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJ0ZW1wIiwiZmlsdGVyIiwiYmFza2V0RWwiLCJfaWQiLCJsZW5ndGgiLCJhbGVydCIsIl9fdHlwZW5hbWUiLCJuZXdFbCIsInB1c2giLCJzZXRJdGVtIiwic3RyaW5naWZ5Iiwib25DbGlja0RlbGV0ZSIsIm5ld0Jhc2tldHMiLCJ0aXRsZSIsIndyaXRlciJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/27test/boardsItem/index.tsx\n");

/***/ }),

/***/ "./pages/27test/index.tsx":
/*!********************************!*\
  !*** ./pages/27test/index.tsx ***!
  \********************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ BasketPage)\n/* harmony export */ });\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @apollo/client */ \"@apollo/client\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _boardsItem__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./boardsItem */ \"./pages/27test/boardsItem/index.tsx\");\n/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! uuid */ \"uuid\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__);\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([uuid__WEBPACK_IMPORTED_MODULE_2__]);\nuuid__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\nvar _jsxFileName = \"C:\\\\Users\\\\cicls_000\\\\Desktop\\\\codecamp-frontend-06\\\\quiz\\\\pages\\\\27test\\\\index.tsx\";\n\n\n\n\nconst FETCH_BOARDS = _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`\n  query fetchBoards {\n    fetchBoards {\n      _id\n      writer\n      title\n      contents\n    }\n  }\n`;\nfunction BasketPage() {\n  const {\n    data\n  } = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_0__.useQuery)(FETCH_BOARDS);\n  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(\"div\", {\n    children: [\" \", data === null || data === void 0 ? void 0 : data.fetchBoards.map((el, index) => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_boardsItem__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {\n      index: index,\n      el: el\n    }, (0,uuid__WEBPACK_IMPORTED_MODULE_2__.v4)(), false, {\n      fileName: _jsxFileName,\n      lineNumber: 31,\n      columnNumber: 9\n    }, this))]\n  }, void 0, true, {\n    fileName: _jsxFileName,\n    lineNumber: 28,\n    columnNumber: 5\n  }, this);\n}\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8yN3Rlc3QvaW5kZXgudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFPQTtBQUNBOztBQUVBLE1BQU1LLFlBQVksR0FBR0wsK0NBQUk7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBVEE7QUFXZSxTQUFTTSxVQUFULEdBQXNCO0FBQ25DLFFBQU07QUFBRUMsSUFBQUE7QUFBRixNQUFXTix3REFBUSxDQUN2QkksWUFEdUIsQ0FBekI7QUFJQSxzQkFDRTtBQUFBLGVBQ0csR0FESCxFQUVHRSxJQUZILGFBRUdBLElBRkgsdUJBRUdBLElBQUksQ0FBRUMsV0FBTixDQUFrQkMsR0FBbEIsQ0FBc0IsQ0FBQ0MsRUFBRCxFQUFhQyxLQUFiLGtCQUNyQiw4REFBQyxtREFBRDtBQUF5QixXQUFLLEVBQUVBLEtBQWhDO0FBQXVDLFFBQUUsRUFBRUQ7QUFBM0MsT0FBaUJOLHdDQUFJLEVBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERCxDQUZIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBUUQsQyIsInNvdXJjZXMiOlsid2VicGFjazovL2NsYXNzLy4vcGFnZXMvMjd0ZXN0L2luZGV4LnRzeD9jYjIxIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGdxbCwgdXNlUXVlcnkgfSBmcm9tIFwiQGFwb2xsby9jbGllbnRcIjtcclxuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHtcclxuICBJQm9hcmQsXHJcbiAgSVF1ZXJ5LFxyXG4gIElRdWVyeUZldGNoQm9hcmRzQXJncyxcclxufSBmcm9tIFwiLi4vLi4vLi4vc3JjL2NvbW1vbnMvdHlwZXMvZ2VuZXJhdGVkL3R5cGVzXCI7XHJcbmltcG9ydCBCb2FyZEl0ZW1zIGZyb20gXCIuL2JvYXJkc0l0ZW1cIjtcclxuaW1wb3J0IHsgdjQgYXMgdXVpZCB9IGZyb20gXCJ1dWlkXCI7XHJcblxyXG5jb25zdCBGRVRDSF9CT0FSRFMgPSBncWxgXHJcbiAgcXVlcnkgZmV0Y2hCb2FyZHMge1xyXG4gICAgZmV0Y2hCb2FyZHMge1xyXG4gICAgICBfaWRcclxuICAgICAgd3JpdGVyXHJcbiAgICAgIHRpdGxlXHJcbiAgICAgIGNvbnRlbnRzXHJcbiAgICB9XHJcbiAgfVxyXG5gO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQmFza2V0UGFnZSgpIHtcclxuICBjb25zdCB7IGRhdGEgfSA9IHVzZVF1ZXJ5PFBpY2s8SVF1ZXJ5LCBcImZldGNoQm9hcmRzXCI+LCBJUXVlcnlGZXRjaEJvYXJkc0FyZ3M+KFxyXG4gICAgRkVUQ0hfQk9BUkRTXHJcbiAgKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXY+XHJcbiAgICAgIHtcIiBcIn1cclxuICAgICAge2RhdGE/LmZldGNoQm9hcmRzLm1hcCgoZWw6IElCb2FyZCwgaW5kZXgpID0+IChcclxuICAgICAgICA8Qm9hcmRJdGVtcyBrZXk9e3V1aWQoKX0gaW5kZXg9e2luZGV4fSBlbD17ZWx9IC8+XHJcbiAgICAgICkpfVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufSJdLCJuYW1lcyI6WyJncWwiLCJ1c2VRdWVyeSIsIkJvYXJkSXRlbXMiLCJ2NCIsInV1aWQiLCJGRVRDSF9CT0FSRFMiLCJCYXNrZXRQYWdlIiwiZGF0YSIsImZldGNoQm9hcmRzIiwibWFwIiwiZWwiLCJpbmRleCJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/27test/index.tsx\n");

/***/ }),

/***/ "@apollo/client":
/*!*********************************!*\
  !*** external "@apollo/client" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "uuid":
/*!***********************!*\
  !*** external "uuid" ***!
  \***********************/
/***/ ((module) => {

module.exports = import("uuid");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/27test/index.tsx"));
module.exports = __webpack_exports__;

})();