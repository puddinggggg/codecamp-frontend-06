"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/22-02";
exports.ids = ["pages/22-02"];
exports.modules = {

/***/ "./pages/22-02/index.tsx":
/*!*******************************!*\
  !*** ./pages/22-02/index.tsx ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ LoginSuccessPage)\n/* harmony export */ });\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @apollo/client */ \"@apollo/client\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! recoil */ \"recoil\");\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var _src_commons_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../src/commons/store */ \"./src/commons/store/index.ts\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__);\nvar _jsxFileName = \"C:\\\\Users\\\\cloubot\\\\Desktop\\\\codecamp_06_sejin\\\\quiz\\\\pages\\\\22-02\\\\index.tsx\";\n\n\n\n\n\n\nconst FETCH_USER_LOGGED_IN = _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`\n  query fetchUserLoggedIn {\n    fetchUserLoggedIn {\n      email\n      name\n    }\n  }\n`;\nfunction LoginSuccessPage() {\n  const {\n    data\n  } = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_0__.useQuery)(FETCH_USER_LOGGED_IN);\n  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();\n  const [accessToken, _] = (0,recoil__WEBPACK_IMPORTED_MODULE_3__.useRecoilState)(_src_commons_store__WEBPACK_IMPORTED_MODULE_4__.accessTokenState);\n  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(() => {\n    if (accessToken === \"\") {\n      alert(\"로그인을 먼저해주세요.\");\n      router.push(\"/22-01\");\n    }\n  }, [accessToken]);\n  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(\"div\", {\n    children: [data === null || data === void 0 ? void 0 : data.fetchUserLoggedIn.name, \" \\uB85C\\uADF8\\uC778\"]\n  }, void 0, true, {\n    fileName: _jsxFileName,\n    lineNumber: 27,\n    columnNumber: 10\n  }, this);\n}//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8yMi0wMi9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsTUFBTU0sb0JBQW9CLEdBQUdOLCtDQUFJO0FBQ2pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBUEE7QUFTZSxTQUFTTyxnQkFBVCxHQUE0QjtBQUN6QyxRQUFNO0FBQUVDLElBQUFBO0FBQUYsTUFBV1Asd0RBQVEsQ0FBQ0ssb0JBQUQsQ0FBekI7QUFDQSxRQUFNRyxNQUFNLEdBQUdQLHNEQUFTLEVBQXhCO0FBQ0EsUUFBTSxDQUFDUSxXQUFELEVBQWNDLENBQWQsSUFBbUJQLHNEQUFjLENBQUNDLGdFQUFELENBQXZDO0FBQ0FGLEVBQUFBLGdEQUFTLENBQUMsTUFBTTtBQUNkLFFBQUlPLFdBQVcsS0FBSyxFQUFwQixFQUF3QjtBQUN0QkUsTUFBQUEsS0FBSyxDQUFDLGNBQUQsQ0FBTDtBQUNBSCxNQUFBQSxNQUFNLENBQUNJLElBQVAsQ0FBWSxRQUFaO0FBQ0Q7QUFDRixHQUxRLEVBS04sQ0FBQ0gsV0FBRCxDQUxNLENBQVQ7QUFPQSxzQkFBTztBQUFBLGVBQU1GLElBQU4sYUFBTUEsSUFBTix1QkFBTUEsSUFBSSxDQUFFTSxpQkFBTixDQUF3QkMsSUFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBQVA7QUFDRCIsInNvdXJjZXMiOlsid2VicGFjazovL2NsYXNzLy4vcGFnZXMvMjItMDIvaW5kZXgudHN4PzU1NDgiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgZ3FsLCB1c2VRdWVyeSB9IGZyb20gXCJAYXBvbGxvL2NsaWVudFwiO1xyXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwibmV4dC9yb3V0ZXJcIjtcclxuaW1wb3J0IHsgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZVJlY29pbFN0YXRlIH0gZnJvbSBcInJlY29pbFwiO1xyXG5pbXBvcnQgeyBhY2Nlc3NUb2tlblN0YXRlIH0gZnJvbSBcIi4uLy4uL3NyYy9jb21tb25zL3N0b3JlXCI7XHJcblxyXG5jb25zdCBGRVRDSF9VU0VSX0xPR0dFRF9JTiA9IGdxbGBcclxuICBxdWVyeSBmZXRjaFVzZXJMb2dnZWRJbiB7XHJcbiAgICBmZXRjaFVzZXJMb2dnZWRJbiB7XHJcbiAgICAgIGVtYWlsXHJcbiAgICAgIG5hbWVcclxuICAgIH1cclxuICB9XHJcbmA7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBMb2dpblN1Y2Nlc3NQYWdlKCkge1xyXG4gIGNvbnN0IHsgZGF0YSB9ID0gdXNlUXVlcnkoRkVUQ0hfVVNFUl9MT0dHRURfSU4pO1xyXG4gIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xyXG4gIGNvbnN0IFthY2Nlc3NUb2tlbiwgX10gPSB1c2VSZWNvaWxTdGF0ZShhY2Nlc3NUb2tlblN0YXRlKTtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKGFjY2Vzc1Rva2VuID09PSBcIlwiKSB7XHJcbiAgICAgIGFsZXJ0KFwi66Gc6re47J247J2EIOuovOyggO2VtOyjvOyEuOyalC5cIik7XHJcbiAgICAgIHJvdXRlci5wdXNoKFwiLzIyLTAxXCIpO1xyXG4gICAgfVxyXG4gIH0sIFthY2Nlc3NUb2tlbl0pO1xyXG5cclxuICByZXR1cm4gPGRpdj57ZGF0YT8uZmV0Y2hVc2VyTG9nZ2VkSW4ubmFtZX0g66Gc6re47J24PC9kaXY+O1xyXG59XHJcbiJdLCJuYW1lcyI6WyJncWwiLCJ1c2VRdWVyeSIsInVzZVJvdXRlciIsInVzZUVmZmVjdCIsInVzZVJlY29pbFN0YXRlIiwiYWNjZXNzVG9rZW5TdGF0ZSIsIkZFVENIX1VTRVJfTE9HR0VEX0lOIiwiTG9naW5TdWNjZXNzUGFnZSIsImRhdGEiLCJyb3V0ZXIiLCJhY2Nlc3NUb2tlbiIsIl8iLCJhbGVydCIsInB1c2giLCJmZXRjaFVzZXJMb2dnZWRJbiIsIm5hbWUiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/22-02/index.tsx\n");

/***/ }),

/***/ "./src/commons/store/index.ts":
/*!************************************!*\
  !*** ./src/commons/store/index.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"isEditState\": () => (/* binding */ isEditState),\n/* harmony export */   \"accessTokenState\": () => (/* binding */ accessTokenState)\n/* harmony export */ });\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! recoil */ \"recoil\");\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_0__);\n\nconst isEditState = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({\n  key: \"isEditState\",\n  default: false\n});\nconst accessTokenState = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({\n  key: \"accessTokenState\",\n  default: \"\"\n});//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tbW9ucy9zdG9yZS9pbmRleC50cy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQUE7QUFFTyxNQUFNQyxXQUFXLEdBQUdELDRDQUFJLENBQUM7QUFDNUJFLEVBQUFBLEdBQUcsRUFBRSxhQUR1QjtBQUU1QkMsRUFBQUEsT0FBTyxFQUFFO0FBRm1CLENBQUQsQ0FBeEI7QUFJQSxNQUFNQyxnQkFBZ0IsR0FBR0osNENBQUksQ0FBQztBQUNqQ0UsRUFBQUEsR0FBRyxFQUFFLGtCQUQ0QjtBQUVqQ0MsRUFBQUEsT0FBTyxFQUFFO0FBRndCLENBQUQsQ0FBN0IiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jbGFzcy8uL3NyYy9jb21tb25zL3N0b3JlL2luZGV4LnRzPzNjYmYiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgYXRvbSB9IGZyb20gXCJyZWNvaWxcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBpc0VkaXRTdGF0ZSA9IGF0b20oe1xyXG4gICAga2V5OiBcImlzRWRpdFN0YXRlXCIsXHJcbiAgICBkZWZhdWx0OiBmYWxzZSxcclxufSlcclxuZXhwb3J0IGNvbnN0IGFjY2Vzc1Rva2VuU3RhdGUgPSBhdG9tKHtcclxuICAgIGtleTogXCJhY2Nlc3NUb2tlblN0YXRlXCIsXHJcbiAgICBkZWZhdWx0OiBcIlwiLFxyXG59KSJdLCJuYW1lcyI6WyJhdG9tIiwiaXNFZGl0U3RhdGUiLCJrZXkiLCJkZWZhdWx0IiwiYWNjZXNzVG9rZW5TdGF0ZSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/commons/store/index.ts\n");

/***/ }),

/***/ "@apollo/client":
/*!*********************************!*\
  !*** external "@apollo/client" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "recoil":
/*!*************************!*\
  !*** external "recoil" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("recoil");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/22-02/index.tsx"));
module.exports = __webpack_exports__;

})();