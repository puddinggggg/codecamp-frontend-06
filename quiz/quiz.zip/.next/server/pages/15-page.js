"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/15-page";
exports.ids = ["pages/15-page"];
exports.modules = {

/***/ "./pages/15-page/index.tsx":
/*!*********************************!*\
  !*** ./pages/15-page/index.tsx ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ StaticRoutedPage)\n/* harmony export */ });\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @apollo/client */ \"@apollo/client\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react_infinite_scroller__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-infinite-scroller */ \"react-infinite-scroller\");\n/* harmony import */ var react_infinite_scroller__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_infinite_scroller__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__);\nvar _jsxFileName = \"C:\\\\Users\\\\cloubot\\\\Desktop\\\\codecamp_06_sejin\\\\quiz\\\\pages\\\\15-page\\\\index.tsx\";\n\n\n\n\nconst FETCH_BOARDS = _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`\n  query fetchBoards($page: Int) {\n    fetchBoards(page: $page) {\n      writer\n      title\n      contents\n      _id\n    }\n  }\n`;\nconst MyRow = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`\n  display: flex;\n  flex-direction: row;\n`;\nconst HeadWrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`\n  display: flex;\n  flex-direction: row;\n`;\nconst ColumnHead = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`\n  padding: 10px;\n  font-weight: bold;\n  width: 50%;\n`;\nconst MyColumn = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`\n  padding: 10px;\n  width: 50%;\n`;\nconst Wrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`\n  height: 500px;\n  overflow: auto;\n  width: 500px;\n`;\nfunction StaticRoutedPage() {\n  const {\n    data,\n    fetchMore\n  } = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_0__.useQuery)(FETCH_BOARDS);\n\n  const onLoadMore = () => {\n    if (!data) return;\n    fetchMore({\n      variables: {\n        page: Math.ceil(data.fetchBoards.length / 10) + 1\n      },\n      updateQuery: (prev, {\n        fetchMoreResult\n      }) => {\n        if (!fetchMoreResult.fetchBoards) {\n          return {\n            fetchBoards: [...prev.fetchBoards]\n          };\n        }\n\n        return {\n          fetchBoards: [...prev.fetchBoards, ...fetchMoreResult.fetchBoards]\n        };\n      }\n    });\n  };\n\n  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(Wrapper, {\n    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(HeadWrapper, {\n      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(ColumnHead, {\n        children: \"\\uC81C\\uBAA9\"\n      }, void 0, false, {\n        fileName: _jsxFileName,\n        lineNumber: 59,\n        columnNumber: 9\n      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(ColumnHead, {\n        children: \"\\uC791\\uC131\\uC790\"\n      }, void 0, false, {\n        fileName: _jsxFileName,\n        lineNumber: 60,\n        columnNumber: 9\n      }, this)]\n    }, void 0, true, {\n      fileName: _jsxFileName,\n      lineNumber: 58,\n      columnNumber: 7\n    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)((react_infinite_scroller__WEBPACK_IMPORTED_MODULE_2___default()), {\n      pageStart: 0,\n      loadMore: onLoadMore,\n      hasMore: true,\n      useWindow: false,\n      loader: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(\"div\", {\n        className: \"loader\",\n        children: \"Loading ...\"\n      }, 0, false, {\n        fileName: _jsxFileName,\n        lineNumber: 68,\n        columnNumber: 11\n      }, this),\n      children: data === null || data === void 0 ? void 0 : data.fetchBoards.map(el => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(MyRow, {\n        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(MyColumn, {\n          children: el.title\n        }, void 0, false, {\n          fileName: _jsxFileName,\n          lineNumber: 75,\n          columnNumber: 13\n        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(MyColumn, {\n          children: el.writer\n        }, void 0, false, {\n          fileName: _jsxFileName,\n          lineNumber: 76,\n          columnNumber: 13\n        }, this)]\n      }, el._id, true, {\n        fileName: _jsxFileName,\n        lineNumber: 74,\n        columnNumber: 11\n      }, this))\n    }, void 0, false, {\n      fileName: _jsxFileName,\n      lineNumber: 62,\n      columnNumber: 7\n    }, this)]\n  }, void 0, true, {\n    fileName: _jsxFileName,\n    lineNumber: 57,\n    columnNumber: 5\n  }, this);\n}//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8xNS1wYWdlL2luZGV4LnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBOztBQUNBLE1BQU1JLFlBQVksR0FBR0gsK0NBQUk7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBVEE7QUFXQSxNQUFNSSxLQUFLLEdBQUdILDREQUFXO0FBQ3pCO0FBQ0E7QUFDQSxDQUhBO0FBSUEsTUFBTUssV0FBVyxHQUFHTCw0REFBVztBQUMvQjtBQUNBO0FBQ0EsQ0FIQTtBQUtBLE1BQU1NLFVBQVUsR0FBR04sNERBQVc7QUFDOUI7QUFDQTtBQUNBO0FBQ0EsQ0FKQTtBQUtBLE1BQU1PLFFBQVEsR0FBR1AsNERBQVc7QUFDNUI7QUFDQTtBQUNBLENBSEE7QUFJQSxNQUFNUSxPQUFPLEdBQUdSLDREQUFXO0FBQzNCO0FBQ0E7QUFDQTtBQUNBLENBSkE7QUFNZSxTQUFTUyxnQkFBVCxHQUE0QjtBQUN6QyxRQUFNO0FBQUVDLElBQUFBLElBQUY7QUFBUUMsSUFBQUE7QUFBUixNQUFzQmIsd0RBQVEsQ0FBQ0ksWUFBRCxDQUFwQzs7QUFFQSxRQUFNVSxVQUFVLEdBQUcsTUFBTTtBQUN2QixRQUFJLENBQUNGLElBQUwsRUFBVztBQUNYQyxJQUFBQSxTQUFTLENBQUM7QUFDUkUsTUFBQUEsU0FBUyxFQUFFO0FBQUVDLFFBQUFBLElBQUksRUFBRUMsSUFBSSxDQUFDQyxJQUFMLENBQVVOLElBQUksQ0FBQ08sV0FBTCxDQUFpQkMsTUFBakIsR0FBMEIsRUFBcEMsSUFBMEM7QUFBbEQsT0FESDtBQUVSQyxNQUFBQSxXQUFXLEVBQUUsQ0FBQ0MsSUFBRCxFQUFPO0FBQUVDLFFBQUFBO0FBQUYsT0FBUCxLQUErQjtBQUMxQyxZQUFJLENBQUNBLGVBQWUsQ0FBQ0osV0FBckIsRUFBa0M7QUFDaEMsaUJBQU87QUFBRUEsWUFBQUEsV0FBVyxFQUFFLENBQUMsR0FBR0csSUFBSSxDQUFDSCxXQUFUO0FBQWYsV0FBUDtBQUNEOztBQUNELGVBQU87QUFDTEEsVUFBQUEsV0FBVyxFQUFFLENBQUMsR0FBR0csSUFBSSxDQUFDSCxXQUFULEVBQXNCLEdBQUdJLGVBQWUsQ0FBQ0osV0FBekM7QUFEUixTQUFQO0FBR0Q7QUFUTyxLQUFELENBQVQ7QUFXRCxHQWJEOztBQWNBLHNCQUNFLDhEQUFDLE9BQUQ7QUFBQSw0QkFDRSw4REFBQyxXQUFEO0FBQUEsOEJBQ0UsOERBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURGLGVBRUUsOERBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGLGVBS0UsOERBQUMsZ0VBQUQ7QUFDRSxlQUFTLEVBQUUsQ0FEYjtBQUVFLGNBQVEsRUFBRUwsVUFGWjtBQUdFLGFBQU8sRUFBRSxJQUhYO0FBSUUsZUFBUyxFQUFFLEtBSmI7QUFLRSxZQUFNLGVBQ0o7QUFBSyxpQkFBUyxFQUFDLFFBQWY7QUFBQTtBQUFBLFNBQTZCLENBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FOSjtBQUFBLGdCQVdHRixJQVhILGFBV0dBLElBWEgsdUJBV0dBLElBQUksQ0FBRU8sV0FBTixDQUFrQkssR0FBbEIsQ0FBdUJDLEVBQUQsaUJBQ3JCLDhEQUFDLEtBQUQ7QUFBQSxnQ0FDRSw4REFBQyxRQUFEO0FBQUEsb0JBQVdBLEVBQUUsQ0FBQ0M7QUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURGLGVBRUUsOERBQUMsUUFBRDtBQUFBLG9CQUFXRCxFQUFFLENBQUNFO0FBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFGRjtBQUFBLFNBQVlGLEVBQUUsQ0FBQ0csR0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREQ7QUFYSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7QUEwQkQiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jbGFzcy8uL3BhZ2VzLzE1LXBhZ2UvaW5kZXgudHN4P2NjYmMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUXVlcnksIGdxbCB9IGZyb20gXCJAYXBvbGxvL2NsaWVudFwiO1xyXG5pbXBvcnQgc3R5bGVkIGZyb20gXCJAZW1vdGlvbi9zdHlsZWRcIjtcclxuaW1wb3J0IEluZmluaXRlU2Nyb2xsIGZyb20gXCJyZWFjdC1pbmZpbml0ZS1zY3JvbGxlclwiO1xyXG5jb25zdCBGRVRDSF9CT0FSRFMgPSBncWxgXHJcbiAgcXVlcnkgZmV0Y2hCb2FyZHMoJHBhZ2U6IEludCkge1xyXG4gICAgZmV0Y2hCb2FyZHMocGFnZTogJHBhZ2UpIHtcclxuICAgICAgd3JpdGVyXHJcbiAgICAgIHRpdGxlXHJcbiAgICAgIGNvbnRlbnRzXHJcbiAgICAgIF9pZFxyXG4gICAgfVxyXG4gIH1cclxuYDtcclxuXHJcbmNvbnN0IE15Um93ID0gc3R5bGVkLmRpdmBcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiByb3c7XHJcbmA7XHJcbmNvbnN0IEhlYWRXcmFwcGVyID0gc3R5bGVkLmRpdmBcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiByb3c7XHJcbmA7XHJcblxyXG5jb25zdCBDb2x1bW5IZWFkID0gc3R5bGVkLmRpdmBcclxuICBwYWRkaW5nOiAxMHB4O1xyXG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gIHdpZHRoOiA1MCU7XHJcbmA7XHJcbmNvbnN0IE15Q29sdW1uID0gc3R5bGVkLmRpdmBcclxuICBwYWRkaW5nOiAxMHB4O1xyXG4gIHdpZHRoOiA1MCU7XHJcbmA7XHJcbmNvbnN0IFdyYXBwZXIgPSBzdHlsZWQuZGl2YFxyXG4gIGhlaWdodDogNTAwcHg7XHJcbiAgb3ZlcmZsb3c6IGF1dG87XHJcbiAgd2lkdGg6IDUwMHB4O1xyXG5gO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gU3RhdGljUm91dGVkUGFnZSgpIHtcclxuICBjb25zdCB7IGRhdGEsIGZldGNoTW9yZSB9ID0gdXNlUXVlcnkoRkVUQ0hfQk9BUkRTKTtcclxuXHJcbiAgY29uc3Qgb25Mb2FkTW9yZSA9ICgpID0+IHtcclxuICAgIGlmICghZGF0YSkgcmV0dXJuO1xyXG4gICAgZmV0Y2hNb3JlKHtcclxuICAgICAgdmFyaWFibGVzOiB7IHBhZ2U6IE1hdGguY2VpbChkYXRhLmZldGNoQm9hcmRzLmxlbmd0aCAvIDEwKSArIDEgfSxcclxuICAgICAgdXBkYXRlUXVlcnk6IChwcmV2LCB7IGZldGNoTW9yZVJlc3VsdCB9KSA9PiB7XHJcbiAgICAgICAgaWYgKCFmZXRjaE1vcmVSZXN1bHQuZmV0Y2hCb2FyZHMpIHtcclxuICAgICAgICAgIHJldHVybiB7IGZldGNoQm9hcmRzOiBbLi4ucHJldi5mZXRjaEJvYXJkc10gfTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgIGZldGNoQm9hcmRzOiBbLi4ucHJldi5mZXRjaEJvYXJkcywgLi4uZmV0Y2hNb3JlUmVzdWx0LmZldGNoQm9hcmRzXSxcclxuICAgICAgICB9O1xyXG4gICAgICB9LFxyXG4gICAgfSk7XHJcbiAgfTtcclxuICByZXR1cm4gKFxyXG4gICAgPFdyYXBwZXI+XHJcbiAgICAgIDxIZWFkV3JhcHBlcj5cclxuICAgICAgICA8Q29sdW1uSGVhZD7soJzrqqk8L0NvbHVtbkhlYWQ+XHJcbiAgICAgICAgPENvbHVtbkhlYWQ+7J6R7ISx7J6QPC9Db2x1bW5IZWFkPlxyXG4gICAgICA8L0hlYWRXcmFwcGVyPlxyXG4gICAgICA8SW5maW5pdGVTY3JvbGxcclxuICAgICAgICBwYWdlU3RhcnQ9ezB9XHJcbiAgICAgICAgbG9hZE1vcmU9e29uTG9hZE1vcmV9XHJcbiAgICAgICAgaGFzTW9yZT17dHJ1ZX1cclxuICAgICAgICB1c2VXaW5kb3c9e2ZhbHNlfVxyXG4gICAgICAgIGxvYWRlcj17XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxvYWRlclwiIGtleT17MH0+XHJcbiAgICAgICAgICAgIExvYWRpbmcgLi4uXHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICB9XHJcbiAgICAgID5cclxuICAgICAgICB7ZGF0YT8uZmV0Y2hCb2FyZHMubWFwKChlbCkgPT4gKFxyXG4gICAgICAgICAgPE15Um93IGtleT17ZWwuX2lkfT5cclxuICAgICAgICAgICAgPE15Q29sdW1uPntlbC50aXRsZX08L015Q29sdW1uPlxyXG4gICAgICAgICAgICA8TXlDb2x1bW4+e2VsLndyaXRlcn08L015Q29sdW1uPlxyXG4gICAgICAgICAgPC9NeVJvdz5cclxuICAgICAgICApKX1cclxuICAgICAgPC9JbmZpbml0ZVNjcm9sbD5cclxuICAgIDwvV3JhcHBlcj5cclxuICApO1xyXG59XHJcbiJdLCJuYW1lcyI6WyJ1c2VRdWVyeSIsImdxbCIsInN0eWxlZCIsIkluZmluaXRlU2Nyb2xsIiwiRkVUQ0hfQk9BUkRTIiwiTXlSb3ciLCJkaXYiLCJIZWFkV3JhcHBlciIsIkNvbHVtbkhlYWQiLCJNeUNvbHVtbiIsIldyYXBwZXIiLCJTdGF0aWNSb3V0ZWRQYWdlIiwiZGF0YSIsImZldGNoTW9yZSIsIm9uTG9hZE1vcmUiLCJ2YXJpYWJsZXMiLCJwYWdlIiwiTWF0aCIsImNlaWwiLCJmZXRjaEJvYXJkcyIsImxlbmd0aCIsInVwZGF0ZVF1ZXJ5IiwicHJldiIsImZldGNoTW9yZVJlc3VsdCIsIm1hcCIsImVsIiwidGl0bGUiLCJ3cml0ZXIiLCJfaWQiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/15-page/index.tsx\n");

/***/ }),

/***/ "@apollo/client":
/*!*********************************!*\
  !*** external "@apollo/client" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ "@emotion/styled":
/*!**********************************!*\
  !*** external "@emotion/styled" ***!
  \**********************************/
/***/ ((module) => {

module.exports = require("@emotion/styled");

/***/ }),

/***/ "react-infinite-scroller":
/*!******************************************!*\
  !*** external "react-infinite-scroller" ***!
  \******************************************/
/***/ ((module) => {

module.exports = require("react-infinite-scroller");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/15-page/index.tsx"));
module.exports = __webpack_exports__;

})();