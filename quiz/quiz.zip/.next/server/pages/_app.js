/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./pages/_app.tsx":
/*!************************!*\
  !*** ./pages/_app.tsx ***!
  \************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../styles/globals.css */ \"./styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var antd_dist_antd_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd/dist/antd.css */ \"./node_modules/antd/dist/antd.css\");\n/* harmony import */ var antd_dist_antd_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd_dist_antd_css__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _src_components_commons_layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../src/components/commons/layout */ \"./src/components/commons/layout/index.tsx\");\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! recoil */ \"recoil\");\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var _src_components_commons_apollo__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../src/components/commons/apollo */ \"./src/components/commons/apollo/index.tsx\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__);\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_src_components_commons_apollo__WEBPACK_IMPORTED_MODULE_4__]);\n_src_components_commons_apollo__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\nvar _jsxFileName = \"C:\\\\Users\\\\cicls_000\\\\Desktop\\\\codecamp-frontend-06\\\\quiz\\\\pages\\\\_app.tsx\";\n\nfunction ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }\n\nfunction _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }\n\nfunction _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }\n\n\n\n\n\n // import { Global } from \"@emotion/react\";\n// import { globalStyles } from \"../src/commons/styles/globalStyles\";\n\n\n\nfunction MyApp({\n  Component,\n  pageProps\n}) {\n  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(recoil__WEBPACK_IMPORTED_MODULE_3__.RecoilRoot, {\n    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_src_components_commons_apollo__WEBPACK_IMPORTED_MODULE_4__[\"default\"], {\n      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_src_components_commons_layout__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {\n        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(Component, _objectSpread({}, pageProps), void 0, false, {\n          fileName: _jsxFileName,\n          lineNumber: 15,\n          columnNumber: 11\n        }, this)\n      }, void 0, false, {\n        fileName: _jsxFileName,\n        lineNumber: 14,\n        columnNumber: 9\n      }, this)\n    }, void 0, false, {\n      fileName: _jsxFileName,\n      lineNumber: 12,\n      columnNumber: 7\n    }, this)\n  }, void 0, false, {\n    fileName: _jsxFileName,\n    lineNumber: 11,\n    columnNumber: 5\n  }, this);\n}\n\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUVBO0FBQ0E7Q0FFQTtBQUNBOzs7O0FBQ0EsU0FBU0csS0FBVCxDQUFlO0FBQUVDLEVBQUFBLFNBQUY7QUFBYUMsRUFBQUE7QUFBYixDQUFmLEVBQW1EO0FBQ2pELHNCQUNFLDhEQUFDLDhDQUFEO0FBQUEsMkJBQ0UsOERBQUMsc0VBQUQ7QUFBQSw2QkFFRSw4REFBQyxzRUFBRDtBQUFBLCtCQUNFLDhEQUFDLFNBQUQsb0JBQWVBLFNBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBVUQ7O0FBRUQsaUVBQWVGLEtBQWYsRSIsInNvdXJjZXMiOlsid2VicGFjazovL2NsYXNzLy4vcGFnZXMvX2FwcC50c3g/MmZiZSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgXCIuLi9zdHlsZXMvZ2xvYmFscy5jc3NcIjtcclxuaW1wb3J0IFwiYW50ZC9kaXN0L2FudGQuY3NzXCI7XHJcbmltcG9ydCB7IEFwcFByb3BzIH0gZnJvbSBcIm5leHQvYXBwXCI7XHJcbmltcG9ydCBMYXlvdXQgZnJvbSBcIi4uL3NyYy9jb21wb25lbnRzL2NvbW1vbnMvbGF5b3V0XCI7XHJcbmltcG9ydCB7IFJlY29pbFJvb3QgfSBmcm9tIFwicmVjb2lsXCI7XHJcbmltcG9ydCBBcG9sbG9TZXR0aW5nIGZyb20gXCIuLi9zcmMvY29tcG9uZW50cy9jb21tb25zL2Fwb2xsb1wiO1xyXG4vLyBpbXBvcnQgeyBHbG9iYWwgfSBmcm9tIFwiQGVtb3Rpb24vcmVhY3RcIjtcclxuLy8gaW1wb3J0IHsgZ2xvYmFsU3R5bGVzIH0gZnJvbSBcIi4uL3NyYy9jb21tb25zL3N0eWxlcy9nbG9iYWxTdHlsZXNcIjtcclxuZnVuY3Rpb24gTXlBcHAoeyBDb21wb25lbnQsIHBhZ2VQcm9wcyB9OiBBcHBQcm9wcykge1xyXG4gIHJldHVybiAoXHJcbiAgICA8UmVjb2lsUm9vdD5cclxuICAgICAgPEFwb2xsb1NldHRpbmc+XHJcbiAgICAgICAgey8qIDxHbG9iYWwgc3R5bGVzPXtnbG9iYWxTdHlsZXN9IC8+ICovfVxyXG4gICAgICAgIDxMYXlvdXQ+XHJcbiAgICAgICAgICA8Q29tcG9uZW50IHsuLi5wYWdlUHJvcHN9IC8+XHJcbiAgICAgICAgPC9MYXlvdXQ+XHJcbiAgICAgIDwvQXBvbGxvU2V0dGluZz5cclxuICAgIDwvUmVjb2lsUm9vdD5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBNeUFwcDtcclxuIl0sIm5hbWVzIjpbIkxheW91dCIsIlJlY29pbFJvb3QiLCJBcG9sbG9TZXR0aW5nIiwiTXlBcHAiLCJDb21wb25lbnQiLCJwYWdlUHJvcHMiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/_app.tsx\n");

/***/ }),

/***/ "./src/commons/store/index.ts":
/*!************************************!*\
  !*** ./src/commons/store/index.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"isEditState\": () => (/* binding */ isEditState),\n/* harmony export */   \"accessTokenState\": () => (/* binding */ accessTokenState)\n/* harmony export */ });\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! recoil */ \"recoil\");\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_0__);\n\nconst isEditState = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({\n  key: \"isEditState\",\n  default: false\n});\nconst accessTokenState = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({\n  key: \"accessTokenState\",\n  default: \"\"\n});//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tbW9ucy9zdG9yZS9pbmRleC50cy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQUE7QUFFTyxNQUFNQyxXQUFXLEdBQUdELDRDQUFJLENBQUM7QUFDNUJFLEVBQUFBLEdBQUcsRUFBRSxhQUR1QjtBQUU1QkMsRUFBQUEsT0FBTyxFQUFFO0FBRm1CLENBQUQsQ0FBeEI7QUFJQSxNQUFNQyxnQkFBZ0IsR0FBR0osNENBQUksQ0FBQztBQUNqQ0UsRUFBQUEsR0FBRyxFQUFFLGtCQUQ0QjtBQUVqQ0MsRUFBQUEsT0FBTyxFQUFFO0FBRndCLENBQUQsQ0FBN0IiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jbGFzcy8uL3NyYy9jb21tb25zL3N0b3JlL2luZGV4LnRzPzNjYmYiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgYXRvbSB9IGZyb20gXCJyZWNvaWxcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBpc0VkaXRTdGF0ZSA9IGF0b20oe1xyXG4gICAga2V5OiBcImlzRWRpdFN0YXRlXCIsXHJcbiAgICBkZWZhdWx0OiBmYWxzZSxcclxufSlcclxuZXhwb3J0IGNvbnN0IGFjY2Vzc1Rva2VuU3RhdGUgPSBhdG9tKHtcclxuICAgIGtleTogXCJhY2Nlc3NUb2tlblN0YXRlXCIsXHJcbiAgICBkZWZhdWx0OiBcIlwiLFxyXG59KSJdLCJuYW1lcyI6WyJhdG9tIiwiaXNFZGl0U3RhdGUiLCJrZXkiLCJkZWZhdWx0IiwiYWNjZXNzVG9rZW5TdGF0ZSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/commons/store/index.ts\n");

/***/ }),

/***/ "./src/components/commons/apollo/index.tsx":
/*!*************************************************!*\
  !*** ./src/components/commons/apollo/index.tsx ***!
  \*************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ ApolloSetting)\n/* harmony export */ });\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @apollo/client */ \"@apollo/client\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var apollo_upload_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! apollo-upload-client */ \"apollo-upload-client\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! recoil */ \"recoil\");\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var _commons_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../commons/store */ \"./src/commons/store/index.ts\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__);\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([apollo_upload_client__WEBPACK_IMPORTED_MODULE_1__]);\napollo_upload_client__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\nvar _jsxFileName = \"C:\\\\Users\\\\cicls_000\\\\Desktop\\\\codecamp-frontend-06\\\\quiz\\\\src\\\\components\\\\commons\\\\apollo\\\\index.tsx\";\n\n\n\n\n\n\nfunction ApolloSetting(props) {\n  const [accessToken, setAccessToken] = (0,recoil__WEBPACK_IMPORTED_MODULE_3__.useRecoilState)(_commons_store__WEBPACK_IMPORTED_MODULE_4__.accessTokenState);\n  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(() => {\n    const localAccessToken = localStorage.getItem(\"accessToken\");\n    setAccessToken(localAccessToken || \"\");\n  }, []);\n  const uploadLink = (0,apollo_upload_client__WEBPACK_IMPORTED_MODULE_1__.createUploadLink)({\n    uri: \"http://backend06.codebootcamp.co.kr/graphql\",\n    headers: {\n      Authorization: `Bearer ${accessToken}`\n    }\n  });\n  const client = new _apollo_client__WEBPACK_IMPORTED_MODULE_0__.ApolloClient({\n    link: _apollo_client__WEBPACK_IMPORTED_MODULE_0__.ApolloLink.from([uploadLink]),\n    cache: new _apollo_client__WEBPACK_IMPORTED_MODULE_0__.InMemoryCache()\n  });\n  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_apollo_client__WEBPACK_IMPORTED_MODULE_0__.ApolloProvider, {\n    client: client,\n    children: props.children\n  }, void 0, false, {\n    fileName: _jsxFileName,\n    lineNumber: 26,\n    columnNumber: 10\n  }, this);\n}\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy9jb21tb25zL2Fwb2xsby9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFNQTtBQUNBO0FBQ0E7QUFDQTs7QUFDZSxTQUFTUSxhQUFULENBQXVCQyxLQUF2QixFQUE4QjtBQUMzQyxRQUFNLENBQUNDLFdBQUQsRUFBY0MsY0FBZCxJQUFnQ0wsc0RBQWMsQ0FBQ0MsNERBQUQsQ0FBcEQ7QUFDQUYsRUFBQUEsZ0RBQVMsQ0FBQyxNQUFNO0FBQ2QsVUFBTU8sZ0JBQWdCLEdBQUdDLFlBQVksQ0FBQ0MsT0FBYixDQUFxQixhQUFyQixDQUF6QjtBQUNBSCxJQUFBQSxjQUFjLENBQUNDLGdCQUFnQixJQUFJLEVBQXJCLENBQWQ7QUFDRCxHQUhRLEVBR04sRUFITSxDQUFUO0FBSUEsUUFBTUcsVUFBVSxHQUFHWCxzRUFBZ0IsQ0FBQztBQUNsQ1ksSUFBQUEsR0FBRyxFQUFFLDZDQUQ2QjtBQUVsQ0MsSUFBQUEsT0FBTyxFQUFFO0FBQUVDLE1BQUFBLGFBQWEsRUFBRyxVQUFTUixXQUFZO0FBQXZDO0FBRnlCLEdBQUQsQ0FBbkM7QUFLQSxRQUFNUyxNQUFNLEdBQUcsSUFBSW5CLHdEQUFKLENBQWlCO0FBQzlCb0IsSUFBQUEsSUFBSSxFQUFFbkIsMkRBQUEsQ0FBZ0IsQ0FBQ2MsVUFBRCxDQUFoQixDQUR3QjtBQUU5Qk8sSUFBQUEsS0FBSyxFQUFFLElBQUluQix5REFBSjtBQUZ1QixHQUFqQixDQUFmO0FBSUEsc0JBQU8sOERBQUMsMERBQUQ7QUFBZ0IsVUFBTSxFQUFFZ0IsTUFBeEI7QUFBQSxjQUFpQ1YsS0FBSyxDQUFDYztBQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLFVBQVA7QUFDRCxDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xhc3MvLi9zcmMvY29tcG9uZW50cy9jb21tb25zL2Fwb2xsby9pbmRleC50c3g/MmU4ZSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gIEFwb2xsb0NsaWVudCxcclxuICBBcG9sbG9MaW5rLFxyXG4gIEFwb2xsb1Byb3ZpZGVyLFxyXG4gIEluTWVtb3J5Q2FjaGUsXHJcbn0gZnJvbSBcIkBhcG9sbG8vY2xpZW50XCI7XHJcbmltcG9ydCB7IGNyZWF0ZVVwbG9hZExpbmsgfSBmcm9tIFwiYXBvbGxvLXVwbG9hZC1jbGllbnRcIjtcclxuaW1wb3J0IHsgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZVJlY29pbFN0YXRlIH0gZnJvbSBcInJlY29pbFwiO1xyXG5pbXBvcnQgeyBhY2Nlc3NUb2tlblN0YXRlIH0gZnJvbSBcIi4uLy4uLy4uL2NvbW1vbnMvc3RvcmVcIjtcclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQXBvbGxvU2V0dGluZyhwcm9wcykge1xyXG4gIGNvbnN0IFthY2Nlc3NUb2tlbiwgc2V0QWNjZXNzVG9rZW5dID0gdXNlUmVjb2lsU3RhdGUoYWNjZXNzVG9rZW5TdGF0ZSk7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGxvY2FsQWNjZXNzVG9rZW4gPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImFjY2Vzc1Rva2VuXCIpO1xyXG4gICAgc2V0QWNjZXNzVG9rZW4obG9jYWxBY2Nlc3NUb2tlbiB8fCBcIlwiKTtcclxuICB9LCBbXSk7XHJcbiAgY29uc3QgdXBsb2FkTGluayA9IGNyZWF0ZVVwbG9hZExpbmsoe1xyXG4gICAgdXJpOiBcImh0dHA6Ly9iYWNrZW5kMDYuY29kZWJvb3RjYW1wLmNvLmtyL2dyYXBocWxcIixcclxuICAgIGhlYWRlcnM6IHsgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke2FjY2Vzc1Rva2VufWAgfSxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgY2xpZW50ID0gbmV3IEFwb2xsb0NsaWVudCh7XHJcbiAgICBsaW5rOiBBcG9sbG9MaW5rLmZyb20oW3VwbG9hZExpbmtdKSxcclxuICAgIGNhY2hlOiBuZXcgSW5NZW1vcnlDYWNoZSgpLFxyXG4gIH0pO1xyXG4gIHJldHVybiA8QXBvbGxvUHJvdmlkZXIgY2xpZW50PXtjbGllbnR9Pntwcm9wcy5jaGlsZHJlbn08L0Fwb2xsb1Byb3ZpZGVyPjtcclxufVxyXG4iXSwibmFtZXMiOlsiQXBvbGxvQ2xpZW50IiwiQXBvbGxvTGluayIsIkFwb2xsb1Byb3ZpZGVyIiwiSW5NZW1vcnlDYWNoZSIsImNyZWF0ZVVwbG9hZExpbmsiLCJ1c2VFZmZlY3QiLCJ1c2VSZWNvaWxTdGF0ZSIsImFjY2Vzc1Rva2VuU3RhdGUiLCJBcG9sbG9TZXR0aW5nIiwicHJvcHMiLCJhY2Nlc3NUb2tlbiIsInNldEFjY2Vzc1Rva2VuIiwibG9jYWxBY2Nlc3NUb2tlbiIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJ1cGxvYWRMaW5rIiwidXJpIiwiaGVhZGVycyIsIkF1dGhvcml6YXRpb24iLCJjbGllbnQiLCJsaW5rIiwiZnJvbSIsImNhY2hlIiwiY2hpbGRyZW4iXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/components/commons/apollo/index.tsx\n");

/***/ }),

/***/ "./src/components/commons/layout/banner/index.tsx":
/*!********************************************************!*\
  !*** ./src/components/commons/layout/banner/index.tsx ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ LayoutBanner)\n/* harmony export */ });\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);\nvar _jsxFileName = \"C:\\\\Users\\\\cicls_000\\\\Desktop\\\\codecamp-frontend-06\\\\quiz\\\\src\\\\components\\\\commons\\\\layout\\\\banner\\\\index.tsx\";\n\n\nconst Wrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_0___default().div)`\n  background-color: pink;\n  height: 300px;\n`;\nfunction LayoutBanner() {\n  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(Wrapper, {\n    children: \"Banner area \\uBC30\\uB108\\uC601\\uC5ED\"\n  }, void 0, false, {\n    fileName: _jsxFileName,\n    lineNumber: 7,\n    columnNumber: 10\n  }, this);\n}//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy9jb21tb25zL2xheW91dC9iYW5uZXIvaW5kZXgudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFBOztBQUNBLE1BQU1DLE9BQU8sR0FBR0QsNERBQVc7QUFDM0I7QUFDQTtBQUNBLENBSEE7QUFJZSxTQUFTRyxZQUFULEdBQXdCO0FBQ3JDLHNCQUFPLDhEQUFDLE9BQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFBUDtBQUNEIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xhc3MvLi9zcmMvY29tcG9uZW50cy9jb21tb25zL2xheW91dC9iYW5uZXIvaW5kZXgudHN4P2M4NzQiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHN0eWxlZCBmcm9tIFwiQGVtb3Rpb24vc3R5bGVkXCI7XHJcbmNvbnN0IFdyYXBwZXIgPSBzdHlsZWQuZGl2YFxyXG4gIGJhY2tncm91bmQtY29sb3I6IHBpbms7XHJcbiAgaGVpZ2h0OiAzMDBweDtcclxuYDtcclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTGF5b3V0QmFubmVyKCkge1xyXG4gIHJldHVybiA8V3JhcHBlcj5CYW5uZXIgYXJlYSDrsLDrhIjsmIHsl608L1dyYXBwZXI+O1xyXG59XHJcbiJdLCJuYW1lcyI6WyJzdHlsZWQiLCJXcmFwcGVyIiwiZGl2IiwiTGF5b3V0QmFubmVyIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/components/commons/layout/banner/index.tsx\n");

/***/ }),

/***/ "./src/components/commons/layout/footer/index.tsx":
/*!********************************************************!*\
  !*** ./src/components/commons/layout/footer/index.tsx ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ LayoutFooter)\n/* harmony export */ });\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);\nvar _jsxFileName = \"C:\\\\Users\\\\cicls_000\\\\Desktop\\\\codecamp-frontend-06\\\\quiz\\\\src\\\\components\\\\commons\\\\layout\\\\footer\\\\index.tsx\";\n\n\nfunction LayoutFooter() {\n  const Wrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_0___default().div)`\n    background-color: green;\n    height: 100px;\n  `;\n  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(Wrapper, {\n    children: \"Footer area \\uD48B\\uD130\\uC601\\uC5ED\"\n  }, void 0, false, {\n    fileName: _jsxFileName,\n    lineNumber: 8,\n    columnNumber: 10\n  }, this);\n}//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy9jb21tb25zL2xheW91dC9mb290ZXIvaW5kZXgudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFBOztBQUNlLFNBQVNDLFlBQVQsR0FBd0I7QUFDckMsUUFBTUMsT0FBTyxHQUFHRiw0REFBVztBQUM3QjtBQUNBO0FBQ0EsR0FIRTtBQUtBLHNCQUFPLDhEQUFDLE9BQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFBUDtBQUNEIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xhc3MvLi9zcmMvY29tcG9uZW50cy9jb21tb25zL2xheW91dC9mb290ZXIvaW5kZXgudHN4P2MyYTgiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHN0eWxlZCBmcm9tIFwiQGVtb3Rpb24vc3R5bGVkXCI7XHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIExheW91dEZvb3RlcigpIHtcclxuICBjb25zdCBXcmFwcGVyID0gc3R5bGVkLmRpdmBcclxuICAgIGJhY2tncm91bmQtY29sb3I6IGdyZWVuO1xyXG4gICAgaGVpZ2h0OiAxMDBweDtcclxuICBgO1xyXG5cclxuICByZXR1cm4gPFdyYXBwZXI+Rm9vdGVyIGFyZWEg7ZKL7YSw7JiB7JetPC9XcmFwcGVyPjtcclxufVxyXG4iXSwibmFtZXMiOlsic3R5bGVkIiwiTGF5b3V0Rm9vdGVyIiwiV3JhcHBlciIsImRpdiJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/components/commons/layout/footer/index.tsx\n");

/***/ }),

/***/ "./src/components/commons/layout/header/index.tsx":
/*!********************************************************!*\
  !*** ./src/components/commons/layout/header/index.tsx ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ LayoutHeader)\n/* harmony export */ });\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);\nvar _jsxFileName = \"C:\\\\Users\\\\cicls_000\\\\Desktop\\\\codecamp-frontend-06\\\\quiz\\\\src\\\\components\\\\commons\\\\layout\\\\header\\\\index.tsx\";\n\n\nfunction LayoutHeader() {\n  const Wrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_0___default().div)`\n    background-color: orange;\n    height: 100px;\n  `;\n  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(Wrapper, {\n    children: \"Header area \\uD5E4\\uB354\\uC601\\uC5ED\"\n  }, void 0, false, {\n    fileName: _jsxFileName,\n    lineNumber: 8,\n    columnNumber: 10\n  }, this);\n}//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy9jb21tb25zL2xheW91dC9oZWFkZXIvaW5kZXgudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFBOztBQUNlLFNBQVNDLFlBQVQsR0FBd0I7QUFDckMsUUFBTUMsT0FBTyxHQUFHRiw0REFBVztBQUM3QjtBQUNBO0FBQ0EsR0FIRTtBQUtBLHNCQUFPLDhEQUFDLE9BQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFBUDtBQUNEIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xhc3MvLi9zcmMvY29tcG9uZW50cy9jb21tb25zL2xheW91dC9oZWFkZXIvaW5kZXgudHN4PzY3YjQiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHN0eWxlZCBmcm9tIFwiQGVtb3Rpb24vc3R5bGVkXCI7XHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIExheW91dEhlYWRlcigpIHtcclxuICBjb25zdCBXcmFwcGVyID0gc3R5bGVkLmRpdmBcclxuICAgIGJhY2tncm91bmQtY29sb3I6IG9yYW5nZTtcclxuICAgIGhlaWdodDogMTAwcHg7XHJcbiAgYDtcclxuXHJcbiAgcmV0dXJuIDxXcmFwcGVyPkhlYWRlciBhcmVhIO2XpOuNlOyYgeyXrTwvV3JhcHBlcj47XHJcbn1cclxuIl0sIm5hbWVzIjpbInN0eWxlZCIsIkxheW91dEhlYWRlciIsIldyYXBwZXIiLCJkaXYiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/components/commons/layout/header/index.tsx\n");

/***/ }),

/***/ "./src/components/commons/layout/index.tsx":
/*!*************************************************!*\
  !*** ./src/components/commons/layout/index.tsx ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Layout)\n/* harmony export */ });\n/* harmony import */ var _header__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./header */ \"./src/components/commons/layout/header/index.tsx\");\n/* harmony import */ var _banner__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./banner */ \"./src/components/commons/layout/banner/index.tsx\");\n/* harmony import */ var _navigation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./navigation */ \"./src/components/commons/layout/navigation/index.tsx\");\n/* harmony import */ var _footer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./footer */ \"./src/components/commons/layout/footer/index.tsx\");\n/* harmony import */ var _sidebar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./sidebar */ \"./src/components/commons/layout/sidebar/index.tsx\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_5__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__);\nvar _jsxFileName = \"C:\\\\Users\\\\cicls_000\\\\Desktop\\\\codecamp-frontend-06\\\\quiz\\\\src\\\\components\\\\commons\\\\layout\\\\index.tsx\";\n\n\n\n\n\n\n\n\n\nconst Body = (_emotion_styled__WEBPACK_IMPORTED_MODULE_5___default().div)`\n  height: 500px;\n`;\nconst BodyWrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_5___default().div)`\n  display: flex;\n`;\nfunction Layout(props) {\n  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_6__.useRouter)();\n  console.log(router);\n  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {\n    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(_header__WEBPACK_IMPORTED_MODULE_0__[\"default\"], {}, void 0, false, {\n      fileName: _jsxFileName,\n      lineNumber: 26,\n      columnNumber: 7\n    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(_banner__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {}, void 0, false, {\n      fileName: _jsxFileName,\n      lineNumber: 27,\n      columnNumber: 7\n    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(_navigation__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {}, void 0, false, {\n      fileName: _jsxFileName,\n      lineNumber: 28,\n      columnNumber: 7\n    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(BodyWrapper, {\n      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(_sidebar__WEBPACK_IMPORTED_MODULE_4__[\"default\"], {}, void 0, false, {\n        fileName: _jsxFileName,\n        lineNumber: 30,\n        columnNumber: 9\n      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(Body, {\n        children: props.children\n      }, void 0, false, {\n        fileName: _jsxFileName,\n        lineNumber: 31,\n        columnNumber: 9\n      }, this)]\n    }, void 0, true, {\n      fileName: _jsxFileName,\n      lineNumber: 29,\n      columnNumber: 7\n    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(_footer__WEBPACK_IMPORTED_MODULE_3__[\"default\"], {}, void 0, false, {\n      fileName: _jsxFileName,\n      lineNumber: 33,\n      columnNumber: 7\n    }, this)]\n  }, void 0, true);\n}//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy9jb21tb25zL2xheW91dC9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBOzs7QUFFQSxNQUFNTyxJQUFJLEdBQUdGLDREQUFXO0FBQ3hCO0FBQ0EsQ0FGQTtBQUdBLE1BQU1JLFdBQVcsR0FBR0osNERBQVc7QUFDL0I7QUFDQSxDQUZBO0FBT2UsU0FBU0ssTUFBVCxDQUFnQkMsS0FBaEIsRUFBcUM7QUFDbEQsUUFBTUMsTUFBTSxHQUFHTixzREFBUyxFQUF4QjtBQUNBTyxFQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWUYsTUFBWjtBQUVBLHNCQUNFO0FBQUEsNEJBQ0UsOERBQUMsK0NBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGLGVBRUUsOERBQUMsK0NBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUZGLGVBR0UsOERBQUMsbURBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUhGLGVBSUUsOERBQUMsV0FBRDtBQUFBLDhCQUNFLDhEQUFDLGdEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FERixlQUVFLDhEQUFDLElBQUQ7QUFBQSxrQkFBT0QsS0FBSyxDQUFDSTtBQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFKRixlQVFFLDhEQUFDLCtDQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFSRjtBQUFBLGtCQURGO0FBWUQiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jbGFzcy8uL3NyYy9jb21wb25lbnRzL2NvbW1vbnMvbGF5b3V0L2luZGV4LnRzeD9kOGVjIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBMYXlvdXRIZWFkZXIgZnJvbSBcIi4vaGVhZGVyXCI7XHJcbmltcG9ydCBMYXlvdXRCYW5uZXIgZnJvbSBcIi4vYmFubmVyXCI7XHJcbmltcG9ydCBMYXlvdXROYXZpZ2F0aW9uIGZyb20gXCIuL25hdmlnYXRpb25cIjtcclxuaW1wb3J0IExheW91dEZvb3RlciBmcm9tIFwiLi9mb290ZXJcIjtcclxuaW1wb3J0IExheW91dFNpZGViYXIgZnJvbSBcIi4vc2lkZWJhclwiO1xyXG5pbXBvcnQgc3R5bGVkIGZyb20gXCJAZW1vdGlvbi9zdHlsZWRcIjtcclxuaW1wb3J0IHsgUmVhY3ROb2RlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCJuZXh0L3JvdXRlclwiO1xyXG5cclxuY29uc3QgQm9keSA9IHN0eWxlZC5kaXZgXHJcbiAgaGVpZ2h0OiA1MDBweDtcclxuYDtcclxuY29uc3QgQm9keVdyYXBwZXIgPSBzdHlsZWQuZGl2YFxyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbmA7XHJcblxyXG5pbnRlcmZhY2UgSUxheW91dFByb3BzIHtcclxuICBjaGlsZHJlbjogUmVhY3ROb2RlO1xyXG59XHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIExheW91dChwcm9wczogSUxheW91dFByb3BzKSB7XHJcbiAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XHJcbiAgY29uc29sZS5sb2cocm91dGVyKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxMYXlvdXRIZWFkZXIgLz5cclxuICAgICAgPExheW91dEJhbm5lciAvPlxyXG4gICAgICA8TGF5b3V0TmF2aWdhdGlvbiAvPlxyXG4gICAgICA8Qm9keVdyYXBwZXI+XHJcbiAgICAgICAgPExheW91dFNpZGViYXIgLz5cclxuICAgICAgICA8Qm9keT57cHJvcHMuY2hpbGRyZW59PC9Cb2R5PlxyXG4gICAgICA8L0JvZHlXcmFwcGVyPlxyXG4gICAgICA8TGF5b3V0Rm9vdGVyIC8+XHJcbiAgICA8Lz5cclxuICApO1xyXG59XHJcbiJdLCJuYW1lcyI6WyJMYXlvdXRIZWFkZXIiLCJMYXlvdXRCYW5uZXIiLCJMYXlvdXROYXZpZ2F0aW9uIiwiTGF5b3V0Rm9vdGVyIiwiTGF5b3V0U2lkZWJhciIsInN0eWxlZCIsInVzZVJvdXRlciIsIkJvZHkiLCJkaXYiLCJCb2R5V3JhcHBlciIsIkxheW91dCIsInByb3BzIiwicm91dGVyIiwiY29uc29sZSIsImxvZyIsImNoaWxkcmVuIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/components/commons/layout/index.tsx\n");

/***/ }),

/***/ "./src/components/commons/layout/navigation/index.tsx":
/*!************************************************************!*\
  !*** ./src/components/commons/layout/navigation/index.tsx ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ LayoutNavigation)\n/* harmony export */ });\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);\nvar _jsxFileName = \"C:\\\\Users\\\\cicls_000\\\\Desktop\\\\codecamp-frontend-06\\\\quiz\\\\src\\\\components\\\\commons\\\\layout\\\\navigation\\\\index.tsx\";\n\n\nfunction LayoutNavigation() {\n  const Wrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_0___default().div)`\n    background-color: yellow;\n    height: 50px;\n  `;\n  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(Wrapper, {\n    children: \"Navigation area \\uB0B4\\uBE44\\uC601\\uC5ED\"\n  }, void 0, false, {\n    fileName: _jsxFileName,\n    lineNumber: 8,\n    columnNumber: 10\n  }, this);\n}//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy9jb21tb25zL2xheW91dC9uYXZpZ2F0aW9uL2luZGV4LnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQTs7QUFDZSxTQUFTQyxnQkFBVCxHQUE0QjtBQUN6QyxRQUFNQyxPQUFPLEdBQUdGLDREQUFXO0FBQzdCO0FBQ0E7QUFDQSxHQUhFO0FBS0Esc0JBQU8sOERBQUMsT0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUFQO0FBQ0QiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jbGFzcy8uL3NyYy9jb21wb25lbnRzL2NvbW1vbnMvbGF5b3V0L25hdmlnYXRpb24vaW5kZXgudHN4P2FjZmIiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHN0eWxlZCBmcm9tIFwiQGVtb3Rpb24vc3R5bGVkXCI7XHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIExheW91dE5hdmlnYXRpb24oKSB7XHJcbiAgY29uc3QgV3JhcHBlciA9IHN0eWxlZC5kaXZgXHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB5ZWxsb3c7XHJcbiAgICBoZWlnaHQ6IDUwcHg7XHJcbiAgYDtcclxuXHJcbiAgcmV0dXJuIDxXcmFwcGVyPk5hdmlnYXRpb24gYXJlYSDrgrTruYTsmIHsl608L1dyYXBwZXI+O1xyXG59XHJcbiJdLCJuYW1lcyI6WyJzdHlsZWQiLCJMYXlvdXROYXZpZ2F0aW9uIiwiV3JhcHBlciIsImRpdiJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/components/commons/layout/navigation/index.tsx\n");

/***/ }),

/***/ "./src/components/commons/layout/sidebar/index.tsx":
/*!*********************************************************!*\
  !*** ./src/components/commons/layout/sidebar/index.tsx ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ LayoutSidebar)\n/* harmony export */ });\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);\nvar _jsxFileName = \"C:\\\\Users\\\\cicls_000\\\\Desktop\\\\codecamp-frontend-06\\\\quiz\\\\src\\\\components\\\\commons\\\\layout\\\\sidebar\\\\index.tsx\";\n\n\nfunction LayoutSidebar() {\n  const Wrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_0___default().div)`\n    background-color: lightblue;\n    width: 200px;\n  `;\n  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(Wrapper, {\n    children: \"Sidebar area \\uC0AC\\uC774\\uB4DC\\uBC14\\uC601\\uC5ED\"\n  }, void 0, false, {\n    fileName: _jsxFileName,\n    lineNumber: 8,\n    columnNumber: 10\n  }, this);\n}//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy9jb21tb25zL2xheW91dC9zaWRlYmFyL2luZGV4LnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQTs7QUFDZSxTQUFTQyxhQUFULEdBQXlCO0FBQ3RDLFFBQU1DLE9BQU8sR0FBR0YsNERBQVc7QUFDN0I7QUFDQTtBQUNBLEdBSEU7QUFLQSxzQkFBTyw4REFBQyxPQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBQVA7QUFDRCIsInNvdXJjZXMiOlsid2VicGFjazovL2NsYXNzLy4vc3JjL2NvbXBvbmVudHMvY29tbW9ucy9sYXlvdXQvc2lkZWJhci9pbmRleC50c3g/ODYzNyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgc3R5bGVkIGZyb20gXCJAZW1vdGlvbi9zdHlsZWRcIjtcclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTGF5b3V0U2lkZWJhcigpIHtcclxuICBjb25zdCBXcmFwcGVyID0gc3R5bGVkLmRpdmBcclxuICAgIGJhY2tncm91bmQtY29sb3I6IGxpZ2h0Ymx1ZTtcclxuICAgIHdpZHRoOiAyMDBweDtcclxuICBgO1xyXG5cclxuICByZXR1cm4gPFdyYXBwZXI+U2lkZWJhciBhcmVhIOyCrOydtOuTnOuwlOyYgeyXrTwvV3JhcHBlcj47XHJcbn1cclxuIl0sIm5hbWVzIjpbInN0eWxlZCIsIkxheW91dFNpZGViYXIiLCJXcmFwcGVyIiwiZGl2Il0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/components/commons/layout/sidebar/index.tsx\n");

/***/ }),

/***/ "./node_modules/antd/dist/antd.css":
/*!*****************************************!*\
  !*** ./node_modules/antd/dist/antd.css ***!
  \*****************************************/
/***/ (() => {



/***/ }),

/***/ "./styles/globals.css":
/*!****************************!*\
  !*** ./styles/globals.css ***!
  \****************************/
/***/ (() => {



/***/ }),

/***/ "@apollo/client":
/*!*********************************!*\
  !*** external "@apollo/client" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@apollo/client");

/***/ }),

/***/ "@emotion/styled":
/*!**********************************!*\
  !*** external "@emotion/styled" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@emotion/styled");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "recoil":
/*!*************************!*\
  !*** external "recoil" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("recoil");

/***/ }),

/***/ "apollo-upload-client":
/*!***************************************!*\
  !*** external "apollo-upload-client" ***!
  \***************************************/
/***/ ((module) => {

"use strict";
module.exports = import("apollo-upload-client");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_app.tsx"));
module.exports = __webpack_exports__;

})();