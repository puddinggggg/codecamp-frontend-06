"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/21-04";
exports.ids = ["pages/21-04"];
exports.modules = {

/***/ "./pages/21-04/index.tsx":
/*!*******************************!*\
  !*** ./pages/21-04/index.tsx ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ DateDot)\n/* harmony export */ });\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);\nvar _jsxFileName = \"C:\\\\Users\\\\cloubot\\\\Desktop\\\\codecamp_06_sejin\\\\quiz\\\\pages\\\\21-04\\\\index.tsx\";\n\n\nconst DateInput = (_emotion_styled__WEBPACK_IMPORTED_MODULE_0___default().input)``;\nfunction DateDot() {\n  const onChangeDate = event => {\n    event.target.value;\n\n    if (event.target.value.length === 4) {\n      event.target.value = event.target.value + \".\";\n    }\n\n    if (event.target.value === 7) {\n      event.target.value = event.target.value + \".\";\n    }\n  };\n\n  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(DateInput, {\n    onChange: onChangeDate,\n    type: \"text\",\n    maxLength: 10\n  }, void 0, false, {\n    fileName: _jsxFileName,\n    lineNumber: 13,\n    columnNumber: 10\n  }, this);\n}//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8yMS0wNC9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQUE7O0FBQ0EsTUFBTUMsU0FBUyxHQUFHRCw4REFBYSxFQUEvQjtBQUNlLFNBQVNHLE9BQVQsR0FBbUI7QUFDaEMsUUFBTUMsWUFBWSxHQUFJQyxLQUFELElBQVc7QUFDOUJBLElBQUFBLEtBQUssQ0FBQ0MsTUFBTixDQUFhQyxLQUFiOztBQUNBLFFBQUlGLEtBQUssQ0FBQ0MsTUFBTixDQUFhQyxLQUFiLENBQW1CQyxNQUFuQixLQUE4QixDQUFsQyxFQUFxQztBQUNuQ0gsTUFBQUEsS0FBSyxDQUFDQyxNQUFOLENBQWFDLEtBQWIsR0FBcUJGLEtBQUssQ0FBQ0MsTUFBTixDQUFhQyxLQUFiLEdBQXFCLEdBQTFDO0FBQ0Q7O0FBQ0QsUUFBSUYsS0FBSyxDQUFDQyxNQUFOLENBQWFDLEtBQWIsS0FBdUIsQ0FBM0IsRUFBOEI7QUFDNUJGLE1BQUFBLEtBQUssQ0FBQ0MsTUFBTixDQUFhQyxLQUFiLEdBQXFCRixLQUFLLENBQUNDLE1BQU4sQ0FBYUMsS0FBYixHQUFxQixHQUExQztBQUNEO0FBQ0YsR0FSRDs7QUFTQSxzQkFBTyw4REFBQyxTQUFEO0FBQVcsWUFBUSxFQUFFSCxZQUFyQjtBQUFtQyxRQUFJLEVBQUMsTUFBeEM7QUFBK0MsYUFBUyxFQUFFO0FBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFBUDtBQUNEIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xhc3MvLi9wYWdlcy8yMS0wNC9pbmRleC50c3g/MTI4YSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgc3R5bGVkIGZyb20gXCJAZW1vdGlvbi9zdHlsZWRcIjtcclxuY29uc3QgRGF0ZUlucHV0ID0gc3R5bGVkLmlucHV0YGA7XHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIERhdGVEb3QoKSB7XHJcbiAgY29uc3Qgb25DaGFuZ2VEYXRlID0gKGV2ZW50KSA9PiB7XHJcbiAgICBldmVudC50YXJnZXQudmFsdWU7XHJcbiAgICBpZiAoZXZlbnQudGFyZ2V0LnZhbHVlLmxlbmd0aCA9PT0gNCkge1xyXG4gICAgICBldmVudC50YXJnZXQudmFsdWUgPSBldmVudC50YXJnZXQudmFsdWUgKyBcIi5cIjtcclxuICAgIH1cclxuICAgIGlmIChldmVudC50YXJnZXQudmFsdWUgPT09IDcpIHtcclxuICAgICAgZXZlbnQudGFyZ2V0LnZhbHVlID0gZXZlbnQudGFyZ2V0LnZhbHVlICsgXCIuXCI7XHJcbiAgICB9XHJcbiAgfTtcclxuICByZXR1cm4gPERhdGVJbnB1dCBvbkNoYW5nZT17b25DaGFuZ2VEYXRlfSB0eXBlPVwidGV4dFwiIG1heExlbmd0aD17MTB9IC8+O1xyXG59XHJcbiJdLCJuYW1lcyI6WyJzdHlsZWQiLCJEYXRlSW5wdXQiLCJpbnB1dCIsIkRhdGVEb3QiLCJvbkNoYW5nZURhdGUiLCJldmVudCIsInRhcmdldCIsInZhbHVlIiwibGVuZ3RoIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/21-04/index.tsx\n");

/***/ }),

/***/ "@emotion/styled":
/*!**********************************!*\
  !*** external "@emotion/styled" ***!
  \**********************************/
/***/ ((module) => {

module.exports = require("@emotion/styled");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/21-04/index.tsx"));
module.exports = __webpack_exports__;

})();