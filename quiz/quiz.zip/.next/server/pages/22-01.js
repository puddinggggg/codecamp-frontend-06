"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/22-01";
exports.ids = ["pages/22-01"];
exports.modules = {

/***/ "./pages/22-01/index.tsx":
/*!*******************************!*\
  !*** ./pages/22-01/index.tsx ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ LoginPage)\n/* harmony export */ });\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @apollo/client */ \"@apollo/client\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! recoil */ \"recoil\");\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var _src_commons_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../src/commons/store */ \"./src/commons/store/index.ts\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__);\nvar _jsxFileName = \"C:\\\\Users\\\\cloubot\\\\Desktop\\\\codecamp_06_sejin\\\\quiz\\\\pages\\\\22-01\\\\index.tsx\";\n\n\n\n\n\n\nconst LOGIN_USER = _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`\n  mutation loginUser($email: String!, $password: String!) {\n    loginUser(email: $email, password: $password) {\n      accessToken\n    }\n  }\n`;\nfunction LoginPage() {\n  const [, setAccessToken] = (0,recoil__WEBPACK_IMPORTED_MODULE_3__.useRecoilState)(_src_commons_store__WEBPACK_IMPORTED_MODULE_4__.accessTokenState);\n  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();\n  const {\n    0: email,\n    1: setEmail\n  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(\"\");\n  const {\n    0: password,\n    1: setPassword\n  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(\"\");\n  const [loginUser] = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_0__.useMutation)(LOGIN_USER);\n\n  const onChangeEmail = event => {\n    setEmail(event.target.value);\n  };\n\n  const onChangePassword = event => {\n    setPassword(event.target.value);\n  };\n\n  const onClickLogin = async () => {\n    try {\n      const result = await loginUser({\n        variables: {\n          email,\n          password\n        }\n      });\n      const accessToken = result.data.loginUser.accessToken;\n      setAccessToken(accessToken);\n      alert(\"로그인성공\");\n      router.push(\"/22-02\");\n    } catch (error) {\n      alert(\"로그인을 먼저해주세요.\");\n    }\n  };\n\n  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(\"div\", {\n    children: [\"\\uC774\\uBA54\\uC77C:\", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(\"input\", {\n      onChange: onChangeEmail,\n      type: \"text\"\n    }, void 0, false, {\n      fileName: _jsxFileName,\n      lineNumber: 48,\n      columnNumber: 7\n    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(\"br\", {}, void 0, false, {\n      fileName: _jsxFileName,\n      lineNumber: 49,\n      columnNumber: 7\n    }, this), \"\\uBE44\\uBC00\\uBC88\\uD638:\", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(\"input\", {\n      onChange: onChangePassword,\n      type: \"password\"\n    }, void 0, false, {\n      fileName: _jsxFileName,\n      lineNumber: 51,\n      columnNumber: 7\n    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(\"br\", {}, void 0, false, {\n      fileName: _jsxFileName,\n      lineNumber: 52,\n      columnNumber: 7\n    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(\"button\", {\n      onClick: onClickLogin,\n      children: \" \\uB85C\\uADF8\\uC778\"\n    }, void 0, false, {\n      fileName: _jsxFileName,\n      lineNumber: 53,\n      columnNumber: 7\n    }, this)]\n  }, void 0, true, {\n    fileName: _jsxFileName,\n    lineNumber: 46,\n    columnNumber: 5\n  }, this);\n}//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8yMi0wMS9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsTUFBTU0sVUFBVSxHQUFHTiwrQ0FBSTtBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FOQTtBQVFlLFNBQVNPLFNBQVQsR0FBcUI7QUFDbEMsUUFBTSxHQUFHQyxjQUFILElBQXFCSixzREFBYyxDQUFDQyxnRUFBRCxDQUF6QztBQUNBLFFBQU1JLE1BQU0sR0FBR1Asc0RBQVMsRUFBeEI7QUFDQSxRQUFNO0FBQUEsT0FBQ1EsS0FBRDtBQUFBLE9BQVFDO0FBQVIsTUFBb0JSLCtDQUFRLENBQUMsRUFBRCxDQUFsQztBQUNBLFFBQU07QUFBQSxPQUFDUyxRQUFEO0FBQUEsT0FBV0M7QUFBWCxNQUEwQlYsK0NBQVEsQ0FBQyxFQUFELENBQXhDO0FBQ0EsUUFBTSxDQUFDVyxTQUFELElBQWNiLDJEQUFXLENBQUNLLFVBQUQsQ0FBL0I7O0FBRUEsUUFBTVMsYUFBYSxHQUFJQyxLQUFELElBQVc7QUFDL0JMLElBQUFBLFFBQVEsQ0FBQ0ssS0FBSyxDQUFDQyxNQUFOLENBQWFDLEtBQWQsQ0FBUjtBQUNELEdBRkQ7O0FBR0EsUUFBTUMsZ0JBQWdCLEdBQUlILEtBQUQsSUFBVztBQUNsQ0gsSUFBQUEsV0FBVyxDQUFDRyxLQUFLLENBQUNDLE1BQU4sQ0FBYUMsS0FBZCxDQUFYO0FBQ0QsR0FGRDs7QUFHQSxRQUFNRSxZQUFZLEdBQUcsWUFBWTtBQUMvQixRQUFJO0FBQ0YsWUFBTUMsTUFBTSxHQUFHLE1BQU1QLFNBQVMsQ0FBQztBQUM3QlEsUUFBQUEsU0FBUyxFQUFFO0FBQ1RaLFVBQUFBLEtBRFM7QUFFVEUsVUFBQUE7QUFGUztBQURrQixPQUFELENBQTlCO0FBTUEsWUFBTVcsV0FBVyxHQUFHRixNQUFNLENBQUNHLElBQVAsQ0FBWVYsU0FBWixDQUFzQlMsV0FBMUM7QUFDQWYsTUFBQUEsY0FBYyxDQUFDZSxXQUFELENBQWQ7QUFDQUUsTUFBQUEsS0FBSyxDQUFDLE9BQUQsQ0FBTDtBQUNBaEIsTUFBQUEsTUFBTSxDQUFDaUIsSUFBUCxDQUFZLFFBQVo7QUFDRCxLQVhELENBV0UsT0FBT0MsS0FBUCxFQUFjO0FBQ2RGLE1BQUFBLEtBQUssQ0FBQyxjQUFELENBQUw7QUFDRDtBQUNGLEdBZkQ7O0FBaUJBLHNCQUNFO0FBQUEsbURBRUU7QUFBTyxjQUFRLEVBQUVWLGFBQWpCO0FBQWdDLFVBQUksRUFBQztBQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLFlBRkYsZUFHRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSEYsNENBS0U7QUFBTyxjQUFRLEVBQUVJLGdCQUFqQjtBQUFtQyxVQUFJLEVBQUM7QUFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUxGLGVBTUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU5GLGVBT0U7QUFBUSxhQUFPLEVBQUVDLFlBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7QUFXRCIsInNvdXJjZXMiOlsid2VicGFjazovL2NsYXNzLy4vcGFnZXMvMjItMDEvaW5kZXgudHN4P2ExYTciXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgZ3FsLCB1c2VNdXRhdGlvbiB9IGZyb20gXCJAYXBvbGxvL2NsaWVudFwiO1xyXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwibmV4dC9yb3V0ZXJcIjtcclxuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlUmVjb2lsU3RhdGUgfSBmcm9tIFwicmVjb2lsXCI7XHJcbmltcG9ydCB7IGFjY2Vzc1Rva2VuU3RhdGUgfSBmcm9tIFwiLi4vLi4vc3JjL2NvbW1vbnMvc3RvcmVcIjtcclxuXHJcbmNvbnN0IExPR0lOX1VTRVIgPSBncWxgXHJcbiAgbXV0YXRpb24gbG9naW5Vc2VyKCRlbWFpbDogU3RyaW5nISwgJHBhc3N3b3JkOiBTdHJpbmchKSB7XHJcbiAgICBsb2dpblVzZXIoZW1haWw6ICRlbWFpbCwgcGFzc3dvcmQ6ICRwYXNzd29yZCkge1xyXG4gICAgICBhY2Nlc3NUb2tlblxyXG4gICAgfVxyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIExvZ2luUGFnZSgpIHtcclxuICBjb25zdCBbLCBzZXRBY2Nlc3NUb2tlbl0gPSB1c2VSZWNvaWxTdGF0ZShhY2Nlc3NUb2tlblN0YXRlKTtcclxuICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcclxuICBjb25zdCBbZW1haWwsIHNldEVtYWlsXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtwYXNzd29yZCwgc2V0UGFzc3dvcmRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2xvZ2luVXNlcl0gPSB1c2VNdXRhdGlvbihMT0dJTl9VU0VSKTtcclxuXHJcbiAgY29uc3Qgb25DaGFuZ2VFbWFpbCA9IChldmVudCkgPT4ge1xyXG4gICAgc2V0RW1haWwoZXZlbnQudGFyZ2V0LnZhbHVlKTtcclxuICB9O1xyXG4gIGNvbnN0IG9uQ2hhbmdlUGFzc3dvcmQgPSAoZXZlbnQpID0+IHtcclxuICAgIHNldFBhc3N3b3JkKGV2ZW50LnRhcmdldC52YWx1ZSk7XHJcbiAgfTtcclxuICBjb25zdCBvbkNsaWNrTG9naW4gPSBhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBsb2dpblVzZXIoe1xyXG4gICAgICAgIHZhcmlhYmxlczoge1xyXG4gICAgICAgICAgZW1haWwsXHJcbiAgICAgICAgICBwYXNzd29yZCxcclxuICAgICAgICB9LFxyXG4gICAgICB9KTtcclxuICAgICAgY29uc3QgYWNjZXNzVG9rZW4gPSByZXN1bHQuZGF0YS5sb2dpblVzZXIuYWNjZXNzVG9rZW47XHJcbiAgICAgIHNldEFjY2Vzc1Rva2VuKGFjY2Vzc1Rva2VuKTtcclxuICAgICAgYWxlcnQoXCLroZzqt7jsnbjshLHqs7VcIik7XHJcbiAgICAgIHJvdXRlci5wdXNoKFwiLzIyLTAyXCIpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgYWxlcnQoXCLroZzqt7jsnbjsnYQg66i87KCA7ZW07KO87IS47JqULlwiKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdj5cclxuICAgICAg7J2066mU7J28OlxyXG4gICAgICA8aW5wdXQgb25DaGFuZ2U9e29uQ2hhbmdlRW1haWx9IHR5cGU9XCJ0ZXh0XCIgLz5cclxuICAgICAgPGJyIC8+XHJcbiAgICAgIOu5hOuwgOuyiO2YuDpcclxuICAgICAgPGlucHV0IG9uQ2hhbmdlPXtvbkNoYW5nZVBhc3N3b3JkfSB0eXBlPVwicGFzc3dvcmRcIiAvPlxyXG4gICAgICA8YnIgLz5cclxuICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtvbkNsaWNrTG9naW59PiDroZzqt7jsnbg8L2J1dHRvbj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl0sIm5hbWVzIjpbImdxbCIsInVzZU11dGF0aW9uIiwidXNlUm91dGVyIiwidXNlU3RhdGUiLCJ1c2VSZWNvaWxTdGF0ZSIsImFjY2Vzc1Rva2VuU3RhdGUiLCJMT0dJTl9VU0VSIiwiTG9naW5QYWdlIiwic2V0QWNjZXNzVG9rZW4iLCJyb3V0ZXIiLCJlbWFpbCIsInNldEVtYWlsIiwicGFzc3dvcmQiLCJzZXRQYXNzd29yZCIsImxvZ2luVXNlciIsIm9uQ2hhbmdlRW1haWwiLCJldmVudCIsInRhcmdldCIsInZhbHVlIiwib25DaGFuZ2VQYXNzd29yZCIsIm9uQ2xpY2tMb2dpbiIsInJlc3VsdCIsInZhcmlhYmxlcyIsImFjY2Vzc1Rva2VuIiwiZGF0YSIsImFsZXJ0IiwicHVzaCIsImVycm9yIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/22-01/index.tsx\n");

/***/ }),

/***/ "./src/commons/store/index.ts":
/*!************************************!*\
  !*** ./src/commons/store/index.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"isEditState\": () => (/* binding */ isEditState),\n/* harmony export */   \"accessTokenState\": () => (/* binding */ accessTokenState)\n/* harmony export */ });\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! recoil */ \"recoil\");\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_0__);\n\nconst isEditState = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({\n  key: \"isEditState\",\n  default: false\n});\nconst accessTokenState = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({\n  key: \"accessTokenState\",\n  default: \"\"\n});//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tbW9ucy9zdG9yZS9pbmRleC50cy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQUE7QUFFTyxNQUFNQyxXQUFXLEdBQUdELDRDQUFJLENBQUM7QUFDNUJFLEVBQUFBLEdBQUcsRUFBRSxhQUR1QjtBQUU1QkMsRUFBQUEsT0FBTyxFQUFFO0FBRm1CLENBQUQsQ0FBeEI7QUFJQSxNQUFNQyxnQkFBZ0IsR0FBR0osNENBQUksQ0FBQztBQUNqQ0UsRUFBQUEsR0FBRyxFQUFFLGtCQUQ0QjtBQUVqQ0MsRUFBQUEsT0FBTyxFQUFFO0FBRndCLENBQUQsQ0FBN0IiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jbGFzcy8uL3NyYy9jb21tb25zL3N0b3JlL2luZGV4LnRzPzNjYmYiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgYXRvbSB9IGZyb20gXCJyZWNvaWxcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBpc0VkaXRTdGF0ZSA9IGF0b20oe1xyXG4gICAga2V5OiBcImlzRWRpdFN0YXRlXCIsXHJcbiAgICBkZWZhdWx0OiBmYWxzZSxcclxufSlcclxuZXhwb3J0IGNvbnN0IGFjY2Vzc1Rva2VuU3RhdGUgPSBhdG9tKHtcclxuICAgIGtleTogXCJhY2Nlc3NUb2tlblN0YXRlXCIsXHJcbiAgICBkZWZhdWx0OiBcIlwiLFxyXG59KSJdLCJuYW1lcyI6WyJhdG9tIiwiaXNFZGl0U3RhdGUiLCJrZXkiLCJkZWZhdWx0IiwiYWNjZXNzVG9rZW5TdGF0ZSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/commons/store/index.ts\n");

/***/ }),

/***/ "@apollo/client":
/*!*********************************!*\
  !*** external "@apollo/client" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "recoil":
/*!*************************!*\
  !*** external "recoil" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("recoil");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/22-01/index.tsx"));
module.exports = __webpack_exports__;

})();