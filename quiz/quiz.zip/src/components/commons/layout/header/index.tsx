import styled from "@emotion/styled";
export default function LayoutHeader() {
  const Wrapper = styled.div`
    background-color: orange;
    height: 100px;
  `;

  return <Wrapper>Header area 헤더영역</Wrapper>;
}
