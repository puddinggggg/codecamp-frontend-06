import styled from "@emotion/styled";
const Wrapper = styled.div`
  background-color: pink;
  height: 300px;
`;
export default function LayoutBanner() {
  return <Wrapper>Banner area 배너영역</Wrapper>;
}
