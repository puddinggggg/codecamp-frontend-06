import styled from "@emotion/styled";
export default function LayoutNavigation() {
  const Wrapper = styled.div`
    background-color: yellow;
    height: 50px;
  `;

  return <Wrapper>Navigation area 내비영역</Wrapper>;
}
