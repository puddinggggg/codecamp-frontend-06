import styled from "@emotion/styled";
export default function LayoutSidebar() {
  const Wrapper = styled.div`
    background-color: lightblue;
    width: 200px;
  `;

  return <Wrapper>Sidebar area 사이드바영역</Wrapper>;
}
