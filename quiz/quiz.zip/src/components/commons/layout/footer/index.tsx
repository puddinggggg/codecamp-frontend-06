import styled from "@emotion/styled";
export default function LayoutFooter() {
  const Wrapper = styled.div`
    background-color: green;
    height: 100px;
  `;

  return <Wrapper>Footer area 풋터영역</Wrapper>;
}
