import styled from '@emotion/styled'

export const BoardNumber = styled.div``;
export const BoardWriter = styled.div``;
export const BoardTitle = styled.div``;
export const BoardContents = styled.div``;