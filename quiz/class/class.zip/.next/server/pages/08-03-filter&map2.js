"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/08-03-filter&map2";
exports.ids = ["pages/08-03-filter&map2"];
exports.modules = {

/***/ "./pages/08-03-filter&map2/index.js":
/*!******************************************!*\
  !*** ./pages/08-03-filter&map2/index.js ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ MapFruitsPage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n\nconst fruits = [\n    {\n        number: 1,\n        title: \"레드향\"\n    },\n    {\n        number: 2,\n        title: \"샤인머스켓\"\n    },\n    {\n        number: 3,\n        title: \"산청딸기\"\n    },\n    {\n        number: 4,\n        title: \"한라봉\"\n    },\n    {\n        number: 5,\n        title: \"사과\"\n    },\n    {\n        number: 6,\n        title: \"애플망고\"\n    },\n    {\n        number: 7,\n        title: \"딸기\"\n    },\n    {\n        number: 8,\n        title: \"천혜향\"\n    },\n    {\n        number: 9,\n        title: \"과일선물세트\"\n    },\n    {\n        number: 10,\n        title: \"귤\"\n    }, \n];\nfunction MapFruitsPage() {\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: fruits.filter((el)=>el.number % 2 === 0\n        ).map((el)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                children: [\n                    el.number,\n                    \" \",\n                    el.title\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\Users\\\\cloubot\\\\Desktop\\\\codecamp_06_sejin\\\\quiz\\\\class\\\\pages\\\\08-03-filter&map2\\\\index.js\",\n                lineNumber: 17,\n                columnNumber: 68\n            }, this)\n        )\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\cloubot\\\\Desktop\\\\codecamp_06_sejin\\\\quiz\\\\class\\\\pages\\\\08-03-filter&map2\\\\index.js\",\n        lineNumber: 17,\n        columnNumber: 12\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8wOC0wMy1maWx0ZXImbWFwMi9pbmRleC5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQUEsS0FBSyxDQUFDQSxNQUFNLEdBQUcsQ0FBQztJQUNaLENBQUM7UUFBQ0MsTUFBTSxFQUFFLENBQUM7UUFBRUMsS0FBSyxFQUFFLENBQUs7SUFBTyxDQUFDO0lBQzNCLENBQUw7UUFBQ0QsTUFBTSxFQUFFLENBQUM7UUFBRUMsS0FBSyxFQUFFLENBQU87SUFBVyxDQUFDO0lBQzdCLENBQVQ7UUFBQ0QsTUFBTSxFQUFFLENBQUM7UUFBRUMsS0FBSyxFQUFFLENBQU07SUFBUyxDQUFDO0lBQzVCLENBQVA7UUFBQ0QsTUFBTSxFQUFFLENBQUM7UUFBRUMsS0FBSyxFQUFFLENBQUs7SUFBTyxDQUFDO0lBQzNCLENBQUw7UUFBQ0QsTUFBTSxFQUFFLENBQUM7UUFBRUMsS0FBSyxFQUFFLENBQUk7SUFBSyxDQUFDO0lBQzFCLENBQUg7UUFBQ0QsTUFBTSxFQUFFLENBQUM7UUFBRUMsS0FBSyxFQUFFLENBQU07SUFBUyxDQUFDO0lBQzVCLENBQVA7UUFBQ0QsTUFBTSxFQUFFLENBQUM7UUFBRUMsS0FBSyxFQUFFLENBQUk7SUFBSyxDQUFDO0lBQzFCLENBQUg7UUFBQ0QsTUFBTSxFQUFFLENBQUM7UUFBRUMsS0FBSyxFQUFFLENBQUs7SUFBTyxDQUFDO0lBQzNCLENBQUw7UUFBQ0QsTUFBTSxFQUFFLENBQUM7UUFBRUMsS0FBSyxFQUFFLENBQVE7SUFBYSxDQUFDO0lBQzlCLENBQVg7UUFBQ0QsTUFBTSxFQUFFLEVBQUU7UUFBRUMsS0FBSyxFQUFFLENBQUc7SUFBQyxDQUFDO0FBQzVCLENBQUM7QUFHWSxRQUFRLENBQUNDLGFBQWEsR0FBRyxDQUFDO0lBRXJDLE1BQU0sNkVBQUVDLENBQUc7a0JBQUVKLE1BQU0sQ0FBQ0ssTUFBTSxFQUFFQyxFQUFFLEdBQUlBLEVBQUUsQ0FBQ0wsTUFBTSxHQUFDLENBQUMsS0FBRyxDQUFDO1VBQUdNLEdBQUcsRUFBRUQsRUFBRSwrRUFBS0YsQ0FBRzs7b0JBQUVFLEVBQUUsQ0FBQ0wsTUFBTTtvQkFBQyxDQUFDO29CQUFDSyxFQUFFLENBQUNKLEtBQUs7Ozs7Ozs7Ozs7Ozs7QUFDN0YsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2NsYXNzLy4vcGFnZXMvMDgtMDMtZmlsdGVyJm1hcDIvaW5kZXguanM/YmI0OSJdLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCBmcnVpdHMgPSBbXHJcbiAgICB7IG51bWJlcjogMSwgdGl0bGU6IFwi66CI65Oc7ZalXCIgfSxcclxuICAgIHsgbnVtYmVyOiAyLCB0aXRsZTogXCLsg6TsnbjrqLjsiqTsvJNcIiB9LFxyXG4gICAgeyBudW1iZXI6IDMsIHRpdGxlOiBcIuyCsOyyreuUuOq4sFwiIH0sXHJcbiAgICB7IG51bWJlcjogNCwgdGl0bGU6IFwi7ZWc652867SJXCIgfSxcclxuICAgIHsgbnVtYmVyOiA1LCB0aXRsZTogXCLsgqzqs7xcIiB9LFxyXG4gICAgeyBudW1iZXI6IDYsIHRpdGxlOiBcIuyVoO2UjOunneqzoFwiIH0sXHJcbiAgICB7IG51bWJlcjogNywgdGl0bGU6IFwi65S46riwXCIgfSxcclxuICAgIHsgbnVtYmVyOiA4LCB0aXRsZTogXCLsspztmJztlqVcIiB9LFxyXG4gICAgeyBudW1iZXI6IDksIHRpdGxlOiBcIuqzvOydvOyEoOusvOyEuO2KuFwiIH0sXHJcbiAgICB7IG51bWJlcjogMTAsIHRpdGxlOiBcIuq3pFwiIH0sXHJcbiAgXTtcclxuXHJcbiAgXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1hcEZydWl0c1BhZ2UoKSB7XHJcblxyXG4gICAgcmV0dXJuIDxkaXY+e2ZydWl0cy5maWx0ZXIoKGVsKT0+KGVsLm51bWJlciUyPT09MCkpLm1hcCgoZWwpPT4oPGRpdj57ZWwubnVtYmVyfSB7ZWwudGl0bGV9PC9kaXY+KSl9PC9kaXY+O1xyXG59XHJcbiJdLCJuYW1lcyI6WyJmcnVpdHMiLCJudW1iZXIiLCJ0aXRsZSIsIk1hcEZydWl0c1BhZ2UiLCJkaXYiLCJmaWx0ZXIiLCJlbCIsIm1hcCJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/08-03-filter&map2/index.js\n");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/08-03-filter&map2/index.js"));
module.exports = __webpack_exports__;

})();