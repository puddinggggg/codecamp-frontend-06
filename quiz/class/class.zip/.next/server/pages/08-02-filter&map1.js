"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/08-02-filter&map1";
exports.ids = ["pages/08-02-filter&map1"];
exports.modules = {

/***/ "./pages/08-02-filter&map1/index.js":
/*!******************************************!*\
  !*** ./pages/08-02-filter&map1/index.js ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ MapClassmatesPage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n\nconst classmates = [\n    {\n        name: \"철수\",\n        age: 10,\n        school: \"토끼초등학교\"\n    },\n    {\n        name: \"영희\",\n        age: 13,\n        school: \"다람쥐초등학교\"\n    },\n    {\n        name: \"훈이\",\n        age: 11,\n        school: \"토끼초등학교\"\n    }, \n];\nlet rabbits = classmates.filter((el)=>el.school === \"토끼초등학교\"\n).map((item)=>({\n        name: item.name,\n        age: item.age,\n        candy: 10\n    })\n);\n// rabbits = rabbits.map((item)=>({name: item.name, age: item.age, candy : 10}))\nlet squirrels = classmates.filter((el)=>el.school === \"다람쥐초등학교\"\n).map((item)=>({\n        name: item.name + \"어린이\"\n    })\n);\n// squirrels = squirrels.map((item)=>({name : item.name + \"어린이\"}))\nfunction MapClassmatesPage() {\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n            children: rabbits\n        }, void 0, false, {\n            fileName: \"C:\\\\Users\\\\cloubot\\\\Desktop\\\\codecamp_06_sejin\\\\quiz\\\\class\\\\pages\\\\08-02-filter&map1\\\\index.js\",\n            lineNumber: 16,\n            columnNumber: 5\n        }, this)\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\cloubot\\\\Desktop\\\\codecamp_06_sejin\\\\quiz\\\\class\\\\pages\\\\08-02-filter&map1\\\\index.js\",\n        lineNumber: 13,\n        columnNumber: 5\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8wOC0wMi1maWx0ZXImbWFwMS9pbmRleC5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQUEsS0FBSyxDQUFDQSxVQUFVLEdBQUUsQ0FBQztJQUNmLENBQUNDO1FBQUFBLElBQUksRUFBQyxDQUFJO1FBQU1DLEdBQUcsRUFBQyxFQUFFO1FBQUVDLE1BQU0sRUFBQyxDQUFRO0lBQVksQ0FBQztJQUNwQyxDQUFmRjtRQUFBQSxJQUFJLEVBQUMsQ0FBSTtRQUFNQyxHQUFHLEVBQUMsRUFBRTtRQUFFQyxNQUFNLEVBQUMsQ0FBUztJQUFjLENBQUM7SUFDckMsQ0FBakJGO1FBQUFBLElBQUksRUFBQyxDQUFJO1FBQU1DLEdBQUcsRUFBQyxFQUFFO1FBQUVDLE1BQU0sRUFBQyxDQUFRO0lBQVksQ0FBQztBQUN4QyxDQUFmO0FBQ0QsR0FBRyxDQUFDQyxPQUFPLEdBQUdKLFVBQVUsQ0FBQ0ssTUFBTSxFQUFFQyxFQUFFLEdBQUlBLEVBQUUsQ0FBQ0gsTUFBTSxLQUFJLENBQVE7RUFBZUksR0FBRyxFQUFFQyxJQUFJLElBQUksQ0FBQ1A7UUFBQUEsSUFBSSxFQUFFTyxJQUFJLENBQUNQLElBQUk7UUFBRUMsR0FBRyxFQUFFTSxJQUFJLENBQUNOLEdBQUc7UUFBRU8sS0FBSyxFQUFHLEVBQUU7SUFBQSxDQUFDOztBQUN4SCxFQUFvRTtBQUVoRixHQUFHLENBQUNDLFNBQVMsR0FBR1YsVUFBVSxDQUFDSyxNQUFNLEVBQUVDLEVBQUUsR0FBSUEsRUFBRSxDQUFDSCxNQUFNLEtBQUksQ0FBUztFQUFpQkksR0FBRyxFQUFFQyxJQUFJLElBQUksQ0FBQ1A7UUFBQUEsSUFBSSxFQUFHTyxJQUFJLENBQUNQLElBQUksR0FBRyxDQUFLO0lBQU0sQ0FBQzs7QUFDekcsRUFBOEM7QUFDbkQsUUFBUSxDQUFDVSxpQkFBaUIsR0FBRyxDQUFDO0lBQ3pDLE1BQU0sNkVBQ0xDLENBQUc7OEZBR0hBLENBQUc7c0JBQUVSLE9BQU87Ozs7Ozs7Ozs7O0FBUWpCLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jbGFzcy8uL3BhZ2VzLzA4LTAyLWZpbHRlciZtYXAxL2luZGV4LmpzPzJmYmMiXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgY2xhc3NtYXRlcyA9W1xyXG4gICAge25hbWU6XCLssqDsiJhcIiwgYWdlOjEwLCBzY2hvb2w6XCLthqDrgbzstIjrk7HtlZnqtZBcIn0sXHJcbiAgICB7bmFtZTpcIuyYge2drFwiLCBhZ2U6MTMsIHNjaG9vbDpcIuuLpOuejOylkOy0iOuTse2Vmeq1kFwifSxcclxuICAgIHtuYW1lOlwi7ZuI7J20XCIsIGFnZToxMSwgc2Nob29sOlwi7Yag64G87LSI65Ox7ZWZ6rWQXCJ9LFxyXG5dO1xyXG5sZXQgcmFiYml0cyA9IGNsYXNzbWF0ZXMuZmlsdGVyKChlbCk9PihlbC5zY2hvb2wgPT09XCLthqDrgbzstIjrk7HtlZnqtZBcIikpLm1hcCgoaXRlbSk9Pih7bmFtZTogaXRlbS5uYW1lLCBhZ2U6IGl0ZW0uYWdlLCBjYW5keSA6IDEwfSkpXHJcbi8vIHJhYmJpdHMgPSByYWJiaXRzLm1hcCgoaXRlbSk9Pih7bmFtZTogaXRlbS5uYW1lLCBhZ2U6IGl0ZW0uYWdlLCBjYW5keSA6IDEwfSkpXHJcblxyXG5sZXQgc3F1aXJyZWxzID0gY2xhc3NtYXRlcy5maWx0ZXIoKGVsKT0+KGVsLnNjaG9vbCA9PT1cIuuLpOuejOylkOy0iOuTse2Vmeq1kFwiKSkubWFwKChpdGVtKT0+KHtuYW1lIDogaXRlbS5uYW1lICsgXCLslrTrprDsnbRcIn0pKVxyXG4vLyBzcXVpcnJlbHMgPSBzcXVpcnJlbHMubWFwKChpdGVtKT0+KHtuYW1lIDogaXRlbS5uYW1lICsgXCLslrTrprDsnbRcIn0pKVxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNYXBDbGFzc21hdGVzUGFnZSgpIHsgXHJcbiAgICByZXR1cm4gKFxyXG4gICAgPGRpdj5cclxuICAgIHsvKiA8ZGl2PntjbGFzc21hdGVzLmZpbHRlcigoZWwpPT4oZWwuc2Nob29sID09PVwi7Yag64G87LSI65Ox7ZWZ6rWQXCIpKS5tYXAoKGl0ZW0pPT4oe25hbWU6IGl0ZW0ubmFtZSwgYWdlOiBpdGVtLmFnZSwgY2FuZHkgOiAxMH0pKX08L2Rpdj5cclxuICAgIDxkaXY+e2NsYXNzbWF0ZXMuZmlsdGVyKChlbCk9PihlbC5zY2hvb2wgPT09XCLri6TrnozspZDstIjrk7HtlZnqtZBcIikpLm1hcCgoaXRlbSk9Pih7bmFtZSA6IGl0ZW0ubmFtZSArIFwi7Ja066aw7J20XCJ9KSl9PC9kaXY+ICovfVxyXG4gICAgPGRpdj57cmFiYml0c308L2Rpdj5cclxuICAgIDwvZGl2PlxyXG5cclxuXHJcbiAgICBcclxuXHJcblxyXG4gICAgKVxyXG59Il0sIm5hbWVzIjpbImNsYXNzbWF0ZXMiLCJuYW1lIiwiYWdlIiwic2Nob29sIiwicmFiYml0cyIsImZpbHRlciIsImVsIiwibWFwIiwiaXRlbSIsImNhbmR5Iiwic3F1aXJyZWxzIiwiTWFwQ2xhc3NtYXRlc1BhZ2UiLCJkaXYiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/08-02-filter&map1/index.js\n");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/08-02-filter&map1/index.js"));
module.exports = __webpack_exports__;

})();