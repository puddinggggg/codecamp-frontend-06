import BoardFetch from "../../../src/components/units/07-02-routed/Routed.container";
export default function StaticRoutedPage() {
  return <BoardFetch />;
}
